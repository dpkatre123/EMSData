using OpcUaSimulator.Core.Persistence;
using OpcUaSimulator.Core.Server;
using OpcUaSimulator.Core.Simulation;
using OpcUaSimulator.Core.Validation;

namespace OpcUaSimulator.Tests;

public class ProfileStoreTests
{
    [Fact]
    public void DefaultProfile_IsValid()
    {
        var profile = DefaultProfile.CreateEmsProfile();

        var result = ProfileValidator.Validate(profile);

        Assert.True(result.IsValid, string.Join("; ", result.Errors));
    }

    [Fact]
    public void DefaultProfile_ContainsWritableAndCommandNodes()
    {
        var profile = DefaultProfile.CreateEmsProfile();

        Assert.Contains(profile.Tags, t => t.IsWritable);
        Assert.Contains(profile.Commands, c => c.HandlerKey == "OpenBreaker");
        Assert.Contains(profile.Commands, c => c.HandlerKey == "SetActivePowerLimit");
    }

    [Fact]
    public void Profile_SurvivesJsonRoundTrip()
    {
        var original = DefaultProfile.CreateEmsProfile();

        var json = ProfileStore.Serialize(original);
        var restored = ProfileStore.Deserialize(json);

        Assert.Equal(original.Name, restored.Name);
        Assert.Equal(original.NamespaceUri, restored.NamespaceUri);
        Assert.Equal(original.UpdateIntervalMs, restored.UpdateIntervalMs);
        Assert.Equal(original.Tags.Count, restored.Tags.Count);
        Assert.Equal(original.Commands.Count, restored.Commands.Count);

        foreach (var tag in original.Tags)
        {
            var match = restored.Tags.Single(t => t.NodeId == tag.NodeId);
            Assert.Equal(tag.ControlMode, match.ControlMode);
            Assert.Equal(tag.SignalType, match.SignalType);
            Assert.Equal(tag.DataType, match.DataType);
            Assert.Equal(tag.Min, match.Min);
            Assert.Equal(tag.Max, match.Max);
        }
    }

    [Fact]
    public void RoundTrip_PreservesCommandArguments()
    {
        var original = DefaultProfile.CreateEmsProfile();

        var restored = ProfileStore.Deserialize(ProfileStore.Serialize(original));
        var command = restored.Commands.Single(c => c.HandlerKey == "SetActivePowerLimit");

        Assert.Equal(2, command.InputArguments.Count);
        Assert.Equal(2, command.OutputArguments.Count);
        Assert.Contains(command.InputArguments, a => a.Name == "limitKw");
    }

    [Fact]
    public async Task SaveAndLoad_RoundTripsThroughDisk()
    {
        var path = Path.Combine(Path.GetTempPath(), $"opcsim-{Guid.NewGuid():N}.json");

        try
        {
            var original = DefaultProfile.CreateEmsProfile();
            await ProfileStore.SaveAsync(original, path);

            Assert.True(File.Exists(path));

            var loaded = await ProfileStore.LoadAsync(path);
            Assert.Equal(original.Tags.Count, loaded.Tags.Count);
        }
        finally
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }
    }

    [Fact]
    public async Task LoadAsync_ThrowsOnMissingFile()
    {
        var path = Path.Combine(Path.GetTempPath(), $"missing-{Guid.NewGuid():N}.json");

        await Assert.ThrowsAsync<FileNotFoundException>(() => ProfileStore.LoadAsync(path));
    }

    [Fact]
    public async Task LoadAsync_ThrowsOnInvalidProfile()
    {
        var path = Path.Combine(Path.GetTempPath(), $"invalid-{Guid.NewGuid():N}.json");

        // Two tags sharing a NodeId must be rejected at load time.
        const string json = """
        {
          "name": "Bad",
          "namespaceUri": "http://ges.com/OpcUaSimulator",
          "updateIntervalMs": 1000,
          "tags": [
            { "nodeId": "Dup", "browseName": "A", "min": 0, "max": 10, "periodMs": 1000, "signalType": "Constant" },
            { "nodeId": "Dup", "browseName": "B", "min": 0, "max": 10, "periodMs": 1000, "signalType": "Constant" }
          ],
          "commands": []
        }
        """;

        await File.WriteAllTextAsync(path, json);

        try
        {
            await Assert.ThrowsAsync<InvalidOperationException>(() => ProfileStore.LoadAsync(path));
        }
        finally
        {
            File.Delete(path);
        }
    }

    [Fact]
    public void DefaultProfile_LoadsIntoCoordinatorCleanly()
    {
        var profile = DefaultProfile.CreateEmsProfile();
        var coordinator = new WriteCoordinator();

        coordinator.LoadTags(profile.Tags);
        coordinator.Tick(TimeSpan.FromSeconds(1));

        var snapshot = coordinator.Snapshot();
        Assert.Equal(profile.Tags.Count, snapshot.Count);
        Assert.All(snapshot, r => Assert.NotNull(r.Value));
    }
}
