using Opc.Ua;
using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.Tests;

public class WriteCoordinatorTests
{
    private const string Identity = "tester";

    private static SimTag Tag(
        string nodeId,
        ControlMode mode,
        SimDataType type = SimDataType.Double,
        double min = 0,
        double max = 100,
        double holdSeconds = 30) => new()
        {
            NodeId = nodeId,
            BrowseName = nodeId,
            ControlMode = mode,
            DataType = type,
            Min = min,
            Max = max,
            HoldSeconds = holdSeconds,
            SignalType = SignalType.Constant
        };

    private static WriteCoordinator CoordinatorWith(params SimTag[] tags)
    {
        var coordinator = new WriteCoordinator();
        coordinator.LoadTags(tags);
        return coordinator;
    }

    [Fact]
    public void Write_ToSetpointTag_IsAccepted()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));

        var outcome = coordinator.ApplyClientWrite("Sp", 42d, Identity, hasWriteRole: true);

        Assert.True(outcome.Accepted);
        Assert.Equal(StatusCodes.Good, outcome.StatusCode);
        Assert.True(coordinator.TryGetRuntime("Sp", out var runtime));
        Assert.Equal(42d, runtime!.Value);
    }

    [Fact]
    public void Write_ToSimulatedTag_ReturnsBadNotWritable()
    {
        var coordinator = CoordinatorWith(Tag("Sim", ControlMode.Simulated));

        var outcome = coordinator.ApplyClientWrite("Sim", 42d, Identity, hasWriteRole: true);

        Assert.False(outcome.Accepted);
        Assert.Equal(StatusCodes.BadNotWritable, outcome.StatusCode);
    }

    [Fact]
    public void Write_OutsideRange_ReturnsBadOutOfRange()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint, min: 0, max: 100));

        var outcome = coordinator.ApplyClientWrite("Sp", 250d, Identity, hasWriteRole: true);

        Assert.False(outcome.Accepted);
        Assert.Equal(StatusCodes.BadOutOfRange, outcome.StatusCode);
    }

    [Fact]
    public void Write_WithUnconvertibleValue_ReturnsBadTypeMismatch()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));

        var outcome = coordinator.ApplyClientWrite("Sp", "not-a-number", Identity, hasWriteRole: true);

        Assert.False(outcome.Accepted);
        Assert.Equal(StatusCodes.BadTypeMismatch, outcome.StatusCode);
    }

    [Fact]
    public void Write_WithoutWriteRole_ReturnsBadUserAccessDenied()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));

        var outcome = coordinator.ApplyClientWrite("Sp", 10d, "anonymous", hasWriteRole: false);

        Assert.False(outcome.Accepted);
        Assert.Equal(StatusCodes.BadUserAccessDenied, outcome.StatusCode);
    }

    [Fact]
    public void Write_WhenClientWritesDisabled_ReturnsBadUserAccessDenied()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));
        coordinator.AllowClientWrites = false;

        var outcome = coordinator.ApplyClientWrite("Sp", 10d, Identity, hasWriteRole: true);

        Assert.False(outcome.Accepted);
        Assert.Equal(StatusCodes.BadUserAccessDenied, outcome.StatusCode);
    }

    [Fact]
    public void Write_WithRejectAllFaultInjection_IsRejected()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));
        coordinator.RejectAllWrites = true;

        var outcome = coordinator.ApplyClientWrite("Sp", 10d, Identity, hasWriteRole: true);

        Assert.False(outcome.Accepted);
        Assert.Equal(StatusCodes.BadUserAccessDenied, outcome.StatusCode);
    }

    [Fact]
    public void Write_ToUnknownNode_ReturnsBadNodeIdUnknown()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));

        var outcome = coordinator.ApplyClientWrite("DoesNotExist", 10d, Identity, hasWriteRole: true);

        Assert.False(outcome.Accepted);
        Assert.Equal(StatusCodes.BadNodeIdUnknown, outcome.StatusCode);
    }

    [Fact]
    public void RangeCheck_IsSkipped_ForBooleanAndString()
    {
        var coordinator = CoordinatorWith(
            Tag("Flag", ControlMode.Setpoint, SimDataType.Boolean),
            Tag("Text", ControlMode.Setpoint, SimDataType.String));

        Assert.True(coordinator.ApplyClientWrite("Flag", true, Identity, true).Accepted);
        Assert.True(coordinator.ApplyClientWrite("Text", "hello", Identity, true).Accepted);
    }

    [Fact]
    public void HybridWrite_SuppressesGenerator_UntilHoldExpires()
    {
        // Very short hold so the test does not sleep long.
        var coordinator = CoordinatorWith(Tag("Hy", ControlMode.Hybrid, holdSeconds: 0.3));

        Assert.True(coordinator.ApplyClientWrite("Hy", 77d, Identity, true).Accepted);
        Assert.True(coordinator.TryGetRuntime("Hy", out var runtime));

        // Still held: a tick must not overwrite the client value.
        coordinator.Tick(TimeSpan.FromSeconds(1));
        Assert.Equal(77d, runtime!.Value);
        Assert.True(runtime.IsClientControlled(DateTime.UtcNow));

        Thread.Sleep(400);

        Assert.False(runtime.IsClientControlled(DateTime.UtcNow));
    }

    [Fact]
    public void SetpointTag_IsNeverOverwrittenByTick()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));
        coordinator.ApplyClientWrite("Sp", 55d, Identity, true);

        for (var i = 0; i < 5; i++)
        {
            coordinator.Tick(TimeSpan.FromSeconds(i));
        }

        Assert.True(coordinator.TryGetRuntime("Sp", out var runtime));
        Assert.Equal(55d, runtime!.Value);
    }

    [Fact]
    public void FrozenTag_IsNotUpdatedByTick()
    {
        var tag = Tag("Sim", ControlMode.Simulated);
        tag.SignalType = SignalType.Ramp;
        tag.PeriodMs = 1000;

        var coordinator = CoordinatorWith(tag);
        coordinator.SetFrozen("Sim", true);

        Assert.True(coordinator.TryGetRuntime("Sim", out var runtime));
        var before = runtime!.Value;

        coordinator.Tick(TimeSpan.FromMilliseconds(500));

        Assert.Equal(before, runtime.Value);
    }

    [Fact]
    public void ValueChanged_IsRaised_OnAcceptedWrite()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));
        TagValueChangedEventArgs? captured = null;
        coordinator.ValueChanged += (_, e) => captured = e;

        coordinator.ApplyClientWrite("Sp", 12d, Identity, true);

        Assert.NotNull(captured);
        Assert.Equal("Sp", captured!.NodeId);
        Assert.Equal(12d, captured.Value);
    }

    [Fact]
    public void ValueChanged_IsNotRaised_OnRejectedWrite()
    {
        var coordinator = CoordinatorWith(Tag("Sim", ControlMode.Simulated));
        var raised = false;
        coordinator.ValueChanged += (_, _) => raised = true;

        coordinator.ApplyClientWrite("Sim", 12d, Identity, true);

        Assert.False(raised);
    }

    [Fact]
    public void Audit_RecordsBothAcceptedAndRejectedWrites()
    {
        var coordinator = CoordinatorWith(
            Tag("Sp", ControlMode.Setpoint),
            Tag("Sim", ControlMode.Simulated));

        coordinator.ApplyClientWrite("Sp", 10d, Identity, true);
        coordinator.ApplyClientWrite("Sim", 10d, Identity, true);

        var entries = coordinator.AuditEntries.ToList();
        Assert.Equal(2, entries.Count);
        Assert.Contains(entries, e => e.Accepted && e.NodeId == "Sp");
        Assert.Contains(entries, e => !e.Accepted && e.NodeId == "Sim");
    }

    [Fact]
    public void Audit_IsBounded_ToConfiguredCapacity()
    {
        var coordinator = new WriteCoordinator(auditCapacity: 10);
        coordinator.LoadTags([Tag("Sp", ControlMode.Setpoint)]);

        for (var i = 0; i < 50; i++)
        {
            coordinator.ApplyClientWrite("Sp", (double)(i % 100), Identity, true);
        }

        Assert.True(coordinator.AuditEntries.Count <= 10);
    }

    [Fact]
    public void QualityOverride_IsReflectedInStatusCode()
    {
        var coordinator = CoordinatorWith(Tag("Sp", ControlMode.Setpoint));
        TagValueChangedEventArgs? captured = null;
        coordinator.ValueChanged += (_, e) => captured = e;

        coordinator.SetQualityOverride("Sp", QualityOverride.Bad);

        Assert.NotNull(captured);
        Assert.Equal(StatusCodes.Bad, captured!.StatusCode);
    }

    [Fact]
    public async Task ConcurrentWritesAndTicks_DoNotCorruptState()
    {
        var tags = Enumerable.Range(0, 20)
            .Select(i => Tag($"T{i}", ControlMode.Setpoint))
            .ToArray();

        var coordinator = CoordinatorWith(tags);

        var writer = Task.Run(() =>
        {
            for (var i = 0; i < 2000; i++)
            {
                coordinator.ApplyClientWrite($"T{i % 20}", (double)(i % 100), Identity, true);
            }
        });

        var ticker = Task.Run(() =>
        {
            for (var i = 0; i < 2000; i++)
            {
                coordinator.Tick(TimeSpan.FromMilliseconds(i));
            }
        });

        await Task.WhenAll(writer, ticker).WaitAsync(TimeSpan.FromSeconds(30));

        foreach (var tag in tags)
        {
            Assert.True(coordinator.TryGetRuntime(tag.NodeId, out var runtime));
            Assert.NotNull(runtime!.Value);
            Assert.InRange(Convert.ToDouble(runtime.Value), 0d, 100d);
        }
    }
}
