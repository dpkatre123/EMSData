using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Validation;

namespace OpcUaSimulator.Tests;

public class ProfileValidatorTests
{
    private static SimProfile ProfileWith(params SimTag[] tags) => new()
    {
        Name = "Test",
        UpdateIntervalMs = 1000,
        Tags = [.. tags]
    };

    private static SimTag ValidTag(string nodeId) => new()
    {
        NodeId = nodeId,
        BrowseName = nodeId,
        Min = 0,
        Max = 100,
        PeriodMs = 1000,
        SignalType = SignalType.Sine
    };

    [Fact]
    public void ValidProfile_PassesValidation()
    {
        var result = ProfileValidator.Validate(ProfileWith(ValidTag("A"), ValidTag("B")));

        Assert.True(result.IsValid, string.Join("; ", result.Errors));
    }

    [Fact]
    public void DuplicateNodeIds_AcrossTags_AreRejected()
    {
        var result = ProfileValidator.Validate(ProfileWith(ValidTag("Dup"), ValidTag("Dup")));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("Duplicate NodeId", StringComparison.Ordinal));
    }

    [Fact]
    public void NodeId_CollidingBetweenTagAndCommand_IsRejected()
    {
        // Tags and commands share one address space, so a collision must be caught.
        var profile = ProfileWith(ValidTag("Shared"));
        profile.Commands.Add(new SimCommand
        {
            NodeId = "Shared",
            Name = "DoThing",
            HandlerKey = "DoThing"
        });

        var result = ProfileValidator.Validate(profile);

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("Duplicate NodeId", StringComparison.Ordinal));
    }

    [Fact]
    public void EmptyNodeId_IsRejected()
    {
        var tag = ValidTag("A");
        tag.NodeId = "  ";

        var result = ProfileValidator.Validate(ProfileWith(tag));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("empty NodeId", StringComparison.Ordinal));
    }

    [Fact]
    public void NodeId_WithWhitespace_IsRejected()
    {
        var result = ProfileValidator.Validate(ProfileWith(ValidTag("Bad Id")));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("whitespace", StringComparison.Ordinal));
    }

    [Fact]
    public void MaxLessThanMin_IsRejected()
    {
        var tag = ValidTag("A");
        tag.Min = 100;
        tag.Max = 0;

        var result = ProfileValidator.Validate(ProfileWith(tag));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("less than Min", StringComparison.Ordinal));
    }

    [Fact]
    public void PeriodicSignal_WithZeroPeriod_IsRejected()
    {
        var tag = ValidTag("A");
        tag.SignalType = SignalType.Sine;
        tag.PeriodMs = 0;

        var result = ProfileValidator.Validate(ProfileWith(tag));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("PeriodMs", StringComparison.Ordinal));
    }

    [Fact]
    public void ConstantSignal_WithZeroPeriod_IsAllowed()
    {
        var tag = ValidTag("A");
        tag.SignalType = SignalType.Constant;
        tag.PeriodMs = 0;

        var result = ProfileValidator.Validate(ProfileWith(tag));

        Assert.True(result.IsValid, string.Join("; ", result.Errors));
    }

    [Theory]
    [InlineData(-1d)]
    [InlineData(101d)]
    public void NoisePercent_OutsideZeroToHundred_IsRejected(double noise)
    {
        var tag = ValidTag("A");
        tag.NoisePercent = noise;

        var result = ProfileValidator.Validate(ProfileWith(tag));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("NoisePercent", StringComparison.Ordinal));
    }

    [Fact]
    public void HybridTag_WithNonPositiveHold_IsRejected()
    {
        var tag = ValidTag("A");
        tag.ControlMode = ControlMode.Hybrid;
        tag.HoldSeconds = 0;

        var result = ProfileValidator.Validate(ProfileWith(tag));

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("HoldSeconds", StringComparison.Ordinal));
    }

    [Fact]
    public void UpdateIntervalBelowFloor_IsRejected()
    {
        var profile = ProfileWith(ValidTag("A"));
        profile.UpdateIntervalMs = 10;

        var result = ProfileValidator.Validate(profile);

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("UpdateIntervalMs", StringComparison.Ordinal));
    }

    [Fact]
    public void Command_WithDuplicateInputArguments_IsRejected()
    {
        var profile = ProfileWith(ValidTag("A"));
        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd",
            Name = "DoThing",
            HandlerKey = "DoThing",
            InputArguments =
            [
                new SimArgument { Name = "id" },
                new SimArgument { Name = "ID" }
            ]
        });

        var result = ProfileValidator.Validate(profile);

        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.Contains("duplicate input argument", StringComparison.Ordinal));
    }

    [Fact]
    public void ThrowIfInvalid_ThrowsWithAllErrors()
    {
        var result = ProfileValidator.Validate(ProfileWith(ValidTag("Dup"), ValidTag("Dup")));

        var ex = Assert.Throws<InvalidOperationException>(result.ThrowIfInvalid);
        Assert.Contains("Duplicate NodeId", ex.Message, StringComparison.Ordinal);
    }
}
