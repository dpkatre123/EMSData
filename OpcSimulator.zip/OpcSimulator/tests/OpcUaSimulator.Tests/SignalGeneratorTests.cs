using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.Tests;

public class SignalGeneratorTests
{
    private static SimTag Tag(SignalType type, double min = 0, double max = 100, int periodMs = 10_000) => new()
    {
        NodeId = $"Test.{type}",
        BrowseName = type.ToString(),
        SignalType = type,
        Min = min,
        Max = max,
        PeriodMs = periodMs
    };

    [Theory]
    [InlineData(SignalType.Ramp)]
    [InlineData(SignalType.Sine)]
    [InlineData(SignalType.Square)]
    [InlineData(SignalType.RandomWalk)]
    [InlineData(SignalType.Counter)]
    [InlineData(SignalType.BooleanToggle)]
    public void Generator_StaysWithinConfiguredRange(SignalType type)
    {
        var tag = Tag(type, min: -50, max: 50);
        var generator = SignalGeneratorFactory.Create(tag);

        for (var i = 0; i < 500; i++)
        {
            var value = generator.Next(TimeSpan.FromMilliseconds(i * 100));
            Assert.InRange(value, tag.Min, tag.Max);
        }
    }

    [Fact]
    public void Sine_IsDeterministic_ForSameElapsed()
    {
        var tag = Tag(SignalType.Sine);
        var a = SignalGeneratorFactory.Create(tag);
        var b = SignalGeneratorFactory.Create(tag);

        var elapsed = TimeSpan.FromSeconds(3.7);
        Assert.Equal(a.Next(elapsed), b.Next(elapsed), precision: 10);
    }

    [Fact]
    public void Sine_SpansMinAndMax_AcrossOnePeriod()
    {
        var tag = Tag(SignalType.Sine, min: 0, max: 100, periodMs: 1000);
        var generator = SignalGeneratorFactory.Create(tag);

        double min = double.MaxValue, max = double.MinValue;
        for (var i = 0; i <= 100; i++)
        {
            var v = generator.Next(TimeSpan.FromMilliseconds(i * 10));
            min = Math.Min(min, v);
            max = Math.Max(max, v);
        }

        Assert.True(min < 5d, $"Sine should approach Min, lowest was {min}.");
        Assert.True(max > 95d, $"Sine should approach Max, highest was {max}.");
    }

    [Fact]
    public void Square_TogglesBetweenMinAndMax()
    {
        var tag = Tag(SignalType.Square, min: 10, max: 20, periodMs: 1000);
        var generator = SignalGeneratorFactory.Create(tag);

        Assert.Equal(10d, generator.Next(TimeSpan.FromMilliseconds(100)));
        Assert.Equal(20d, generator.Next(TimeSpan.FromMilliseconds(700)));
    }

    [Fact]
    public void Ramp_IncreasesMonotonically_WithinOnePeriod()
    {
        var tag = Tag(SignalType.Ramp, min: 0, max: 100, periodMs: 1000);
        var generator = SignalGeneratorFactory.Create(tag);

        var previous = double.MinValue;
        for (var i = 0; i < 10; i++)
        {
            var value = generator.Next(TimeSpan.FromMilliseconds(i * 90));
            Assert.True(value > previous, $"Ramp should increase; {value} followed {previous}.");
            previous = value;
        }
    }

    [Fact]
    public void Counter_WrapsBackToMin_WhenExceedingMax()
    {
        var tag = Tag(SignalType.Counter, min: 0, max: 10, periodMs: 1000);
        var generator = SignalGeneratorFactory.Create(tag);

        var sawWrap = false;
        var previous = 0d;
        for (var i = 0; i < 50; i++)
        {
            var value = generator.Next(TimeSpan.FromMilliseconds(i * 100));
            if (value < previous)
            {
                sawWrap = true;
            }

            previous = value;
        }

        Assert.True(sawWrap, "Counter should wrap around to Min.");
    }

    [Fact]
    public void Noise_KeepsValueWithinRange()
    {
        var tag = Tag(SignalType.Constant, min: 0, max: 10);
        tag.InitialValue = 10d;
        tag.NoisePercent = 100d;

        var generator = SignalGeneratorFactory.Create(tag);

        for (var i = 0; i < 200; i++)
        {
            var value = generator.Next(TimeSpan.FromMilliseconds(i * 100));
            Assert.InRange(value, tag.Min, tag.Max);
        }
    }

    [Fact]
    public void ZeroPeriod_DoesNotDivideByZero()
    {
        var tag = Tag(SignalType.Sine, periodMs: 0);
        var generator = SignalGeneratorFactory.Create(tag);

        var value = generator.Next(TimeSpan.FromSeconds(1));
        Assert.False(double.IsNaN(value) || double.IsInfinity(value));
    }
}
