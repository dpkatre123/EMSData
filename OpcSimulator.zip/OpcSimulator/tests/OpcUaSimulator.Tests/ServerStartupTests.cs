using OpcUaSimulator.Core.Persistence;
using OpcUaSimulator.Core.Server;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.Tests;

/// <summary>
/// Verifies the server actually starts against the real OPC UA stack. Configuration and
/// certificate problems only surface at runtime, so a compile-time-clean build proves nothing here.
/// </summary>
public class ServerStartupTests
{
    private static string WriteTestConfig(int port)
    {
        var dir = Path.Combine(Path.GetTempPath(), $"opcsim-cfg-{Guid.NewGuid():N}");
        Directory.CreateDirectory(dir);

        var pki = Path.Combine(dir, "pki").Replace('\\', '/');

        var xml = $"""
        <?xml version="1.0" encoding="utf-8"?>
        <ApplicationConfiguration
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xmlns:ua="http://opcfoundation.org/UA/2008/02/Types.xsd"
          xmlns="http://opcfoundation.org/UA/SDK/Configuration.xsd">
          <ApplicationName>OPC UA Simulator Test</ApplicationName>
          <ApplicationUri>urn:localhost:GES:OpcUaSimulatorTest</ApplicationUri>
          <ProductUri>urn:ges.com:OpcUaSimulatorTest</ProductUri>
          <ApplicationType>Server_0</ApplicationType>
          <SecurityConfiguration>
            <ApplicationCertificate>
              <StoreType>Directory</StoreType>
              <StorePath>{pki}/own</StorePath>
              <SubjectName>CN=OPC UA Simulator Test, O=GES, DC=localhost</SubjectName>
            </ApplicationCertificate>
            <TrustedIssuerCertificates>
              <StoreType>Directory</StoreType>
              <StorePath>{pki}/issuer</StorePath>
            </TrustedIssuerCertificates>
            <TrustedPeerCertificates>
              <StoreType>Directory</StoreType>
              <StorePath>{pki}/trusted</StorePath>
            </TrustedPeerCertificates>
            <RejectedCertificateStore>
              <StoreType>Directory</StoreType>
              <StorePath>{pki}/rejected</StorePath>
            </RejectedCertificateStore>
            <AutoAcceptUntrustedCertificates>true</AutoAcceptUntrustedCertificates>
            <AddAppCertToTrustedStore>true</AddAppCertToTrustedStore>
            <RejectSHA1SignedCertificates>false</RejectSHA1SignedCertificates>
            <MinimumCertificateKeySize>2048</MinimumCertificateKeySize>
          </SecurityConfiguration>
          <TransportConfigurations />
          <TransportQuotas>
            <OperationTimeout>60000</OperationTimeout>
            <MaxStringLength>1048576</MaxStringLength>
            <MaxByteStringLength>1048576</MaxByteStringLength>
            <MaxArrayLength>65535</MaxArrayLength>
            <MaxMessageSize>4194304</MaxMessageSize>
            <MaxBufferSize>65535</MaxBufferSize>
            <ChannelLifetime>300000</ChannelLifetime>
            <SecurityTokenLifetime>3600000</SecurityTokenLifetime>
          </TransportQuotas>
          <ServerConfiguration>
            <BaseAddresses>
              <ua:String>opc.tcp://localhost:{port}/OpcUaSimulatorTest</ua:String>
            </BaseAddresses>
            <SecurityPolicies>
              <ServerSecurityPolicy>
                <SecurityMode>None_1</SecurityMode>
                <SecurityPolicyUri>http://opcfoundation.org/UA/SecurityPolicy#None</SecurityPolicyUri>
              </ServerSecurityPolicy>
            </SecurityPolicies>
            <UserTokenPolicies>
              <ua:UserTokenPolicy><ua:TokenType>Anonymous_0</ua:TokenType></ua:UserTokenPolicy>
              <ua:UserTokenPolicy><ua:TokenType>UserName_1</ua:TokenType></ua:UserTokenPolicy>
            </UserTokenPolicies>
            <DiagnosticsEnabled>false</DiagnosticsEnabled>
            <MaxSessionCount>10</MaxSessionCount>
            <MinSessionTimeout>10000</MinSessionTimeout>
            <MaxSessionTimeout>3600000</MaxSessionTimeout>
            <MaxBrowseContinuationPoints>10</MaxBrowseContinuationPoints>
            <MaxQueryContinuationPoints>10</MaxQueryContinuationPoints>
            <MaxHistoryContinuationPoints>10</MaxHistoryContinuationPoints>
            <MaxRequestAge>600000</MaxRequestAge>
            <MinPublishingInterval>100</MinPublishingInterval>
            <MaxPublishingInterval>3600000</MaxPublishingInterval>
            <PublishingResolution>50</PublishingResolution>
          </ServerConfiguration>
          <TraceConfiguration>
            <OutputFilePath>{dir.Replace('\\', '/')}/trace.log</OutputFilePath>
            <DeleteOnLoad>true</DeleteOnLoad>
            <TraceMasks>0</TraceMasks>
          </TraceConfiguration>
        </ApplicationConfiguration>
        """;

        var path = Path.Combine(dir, "Opc.Ua.Test.Config.xml");
        File.WriteAllText(path, xml);
        return path;
    }

    private static int GetFreePort()
    {
        var listener = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Loopback, 0);
        listener.Start();
        var port = ((System.Net.IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        return port;
    }

    [Fact]
    public async Task Server_StartsAndReportsRunning()
    {
        var port = GetFreePort();
        var configPath = WriteTestConfig(port);
        var coordinator = new WriteCoordinator();
        var controller = new ServerController(coordinator, configPath);

        var logs = new List<string>();
        controller.Log += (_, e) => logs.Add(e.Message);

        try
        {
            await controller.StartAsync(DefaultProfile.CreateEmsProfile());

            Assert.Equal(ServerStatus.Running, controller.Status);
            Assert.NotNull(controller.EndpointUrl);
            Assert.Contains(port.ToString(), controller.EndpointUrl!, StringComparison.Ordinal);
        }
        finally
        {
            await controller.StopAsync();
        }

        Assert.Equal(ServerStatus.Stopped, controller.Status);
    }

    [Fact]
    public async Task Server_PopulatesTagValues_WhileRunning()
    {
        var port = GetFreePort();
        var configPath = WriteTestConfig(port);
        var coordinator = new WriteCoordinator();
        var controller = new ServerController(coordinator, configPath);

        try
        {
            await controller.StartAsync(DefaultProfile.CreateEmsProfile());

            // Let the simulation engine run a few ticks.
            await Task.Delay(2500);

            var snapshot = coordinator.Snapshot();
            Assert.NotEmpty(snapshot);
            Assert.All(snapshot, r => Assert.NotNull(r.Value));
        }
        finally
        {
            await controller.StopAsync();
        }
    }

    [Fact]
    public async Task Server_RejectsInvalidProfile()
    {
        var port = GetFreePort();
        var configPath = WriteTestConfig(port);
        var controller = new ServerController(new WriteCoordinator(), configPath);

        var profile = DefaultProfile.CreateEmsProfile();
        // Introduce a duplicate NodeId; startup must fail fast.
        profile.Tags.Add(profile.Tags[0].Clone());

        await Assert.ThrowsAsync<InvalidOperationException>(() => controller.StartAsync(profile));
        Assert.Equal(ServerStatus.Faulted, controller.Status);
    }
}
