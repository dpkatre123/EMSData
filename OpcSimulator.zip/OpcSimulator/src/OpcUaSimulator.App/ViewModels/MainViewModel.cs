using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Persistence;
using OpcUaSimulator.Core.Server;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.App.ViewModels;

/// <summary>
/// Row shown in the live tag grid. Updated in place so the DataGrid does not rebuild each tick.
/// </summary>
public sealed partial class TagRowViewModel(SimTag tag) : ObservableObject
{
    public SimTag Tag { get; } = tag;

    public string NodeId => Tag.NodeId;

    public string BrowseName => Tag.BrowseName;

    public string FolderPath => Tag.FolderPath;

    public string DataType => Tag.DataType.ToString();

    public string SignalType => Tag.SignalType.ToString();

    public string ControlMode => Tag.ControlMode.ToString();

    public string? Unit => Tag.Unit;

    public bool IsWritable => Tag.IsWritable;

    [ObservableProperty]
    private string _value = "-";

    [ObservableProperty]
    private string _quality = "Good";

    [ObservableProperty]
    private string _timestamp = "-";

    [ObservableProperty]
    private bool _isClientControlled;
}

public sealed partial class MainViewModel : ObservableObject, IDisposable
{
    private readonly WriteCoordinator _coordinator;
    private readonly ServerController _controller;
    private readonly Dispatcher _dispatcher;
    private readonly DispatcherTimer _refreshTimer;
    private readonly Dictionary<string, TagRowViewModel> _rowsByNodeId = new(StringComparer.Ordinal);

    public MainViewModel()
    {
        _dispatcher = Dispatcher.CurrentDispatcher;
        _coordinator = new WriteCoordinator();

        var configPath = Path.Combine(AppContext.BaseDirectory, "Opc.Ua.Config.xml");
        _controller = new ServerController(_coordinator, configPath);

        _controller.Log += OnServerLog;
        _controller.StatusChanged += OnServerStatusChanged;
        _coordinator.Audited += OnAudited;

        Profile = DefaultProfile.CreateEmsProfile();
        BuildTagRows();

        // Poll the coordinator for display rather than binding to every ValueChanged event,
        // which would flood the dispatcher at high tag counts.
        _refreshTimer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(500)
        };
        _refreshTimer.Tick += (_, _) => RefreshValues();
        _refreshTimer.Start();

        AppendLog($"Loaded profile '{Profile.Name}' with {Profile.Tags.Count} tags and {Profile.Commands.Count} commands.");
        AppendLog("Press Start Server to begin.");
    }

    public SimProfile Profile { get; private set; }

    public ObservableCollection<TagRowViewModel> Tags { get; } = [];

    public ObservableCollection<string> LogEntries { get; } = [];

    public ObservableCollection<WriteAuditEntry> AuditEntries { get; } = [];

    [ObservableProperty]
    private string _serverStatus = "Stopped";

    [ObservableProperty]
    private string _endpointUrl = "-";

    [ObservableProperty]
    private bool _isRunning;

    [ObservableProperty]
    private bool _isBusy;

    [ObservableProperty]
    private int _acceptedWrites;

    [ObservableProperty]
    private int _rejectedWrites;

    [ObservableProperty]
    private TagRowViewModel? _selectedTag;

    [ObservableProperty]
    private string _manualValue = string.Empty;

    public bool AllowClientWrites
    {
        get => _coordinator.AllowClientWrites;
        set
        {
            if (_coordinator.AllowClientWrites == value)
            {
                return;
            }

            _coordinator.AllowClientWrites = value;
            OnPropertyChanged();
            AppendLog(value ? "Client writes ENABLED." : "Client writes DISABLED.");
        }
    }

    public bool RejectAllWrites
    {
        get => _coordinator.RejectAllWrites;
        set
        {
            if (_coordinator.RejectAllWrites == value)
            {
                return;
            }

            _coordinator.RejectAllWrites = value;
            OnPropertyChanged();
            AppendLog(value ? "Fault injection: rejecting ALL writes." : "Fault injection: write rejection cleared.");
        }
    }

    private void BuildTagRows()
    {
        Tags.Clear();
        _rowsByNodeId.Clear();

        foreach (var tag in Profile.Tags)
        {
            var row = new TagRowViewModel(tag);
            Tags.Add(row);
            _rowsByNodeId[tag.NodeId] = row;
        }
    }

    private void RefreshValues()
    {
        if (!IsRunning)
        {
            return;
        }

        var nowUtc = DateTime.UtcNow;

        foreach (var runtime in _coordinator.Snapshot())
        {
            if (!_rowsByNodeId.TryGetValue(runtime.Tag.NodeId, out var row))
            {
                continue;
            }

            row.Value = FormatValue(runtime.Value);
            row.Quality = runtime.QualityOverride switch
            {
                QualityOverride.Bad => "Bad",
                QualityOverride.Uncertain => "Uncertain",
                _ => runtime.IsFrozen ? "Frozen" : "Good"
            };
            row.Timestamp = runtime.SourceTimestampUtc.ToLocalTime().ToString("HH:mm:ss");
            row.IsClientControlled = runtime.IsClientControlled(nowUtc);
        }
    }

    private static string FormatValue(object? value) => value switch
    {
        null => "-",
        double d => d.ToString("F2"),
        float f => f.ToString("F2"),
        _ => value.ToString() ?? "-"
    };

    [RelayCommand]
    private async Task StartServerAsync()
    {
        if (IsRunning || IsBusy)
        {
            return;
        }

        IsBusy = true;

        try
        {
            await _controller.StartAsync(Profile);
        }
        catch (Exception ex)
        {
            AppendLog($"ERROR: {ex.Message}");
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    private async Task StopServerAsync()
    {
        if (!IsRunning || IsBusy)
        {
            return;
        }

        IsBusy = true;

        try
        {
            await _controller.StopAsync();
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    private void ApplyManualValue()
    {
        if (SelectedTag is null)
        {
            AppendLog("Select a tag first.");
            return;
        }

        if (string.IsNullOrWhiteSpace(ManualValue))
        {
            AppendLog("Enter a value to apply.");
            return;
        }

        var outcome = _coordinator.ApplyUiOverride(SelectedTag.NodeId, ManualValue);
        AppendLog(outcome.Accepted
            ? $"Set {SelectedTag.NodeId} = {ManualValue}"
            : $"Rejected: {outcome.Message}");
    }

    [RelayCommand]
    private void FreezeSelected()
    {
        if (SelectedTag is null)
        {
            return;
        }

        _coordinator.SetFrozen(SelectedTag.NodeId, true);
        AppendLog($"Froze {SelectedTag.NodeId}.");
    }

    [RelayCommand]
    private void UnfreezeSelected()
    {
        if (SelectedTag is null)
        {
            return;
        }

        _coordinator.SetFrozen(SelectedTag.NodeId, false);
        _coordinator.SetQualityOverride(SelectedTag.NodeId, QualityOverride.None);
        AppendLog($"Cleared faults on {SelectedTag.NodeId}.");
    }

    [RelayCommand]
    private void SetBadQuality()
    {
        if (SelectedTag is null)
        {
            return;
        }

        _coordinator.SetQualityOverride(SelectedTag.NodeId, QualityOverride.Bad);
        AppendLog($"Set {SelectedTag.NodeId} quality to Bad.");
    }

    [RelayCommand]
    private void InjectSpike()
    {
        if (SelectedTag is null)
        {
            return;
        }

        _coordinator.InjectSpike(SelectedTag.NodeId);
        AppendLog($"Injected spike on {SelectedTag.NodeId}.");
    }

    [RelayCommand]
    private void ClearLog() => LogEntries.Clear();

    private void OnServerStatusChanged(object? sender, ServerStatusEventArgs e) =>
        RunOnUi(() =>
        {
            ServerStatus = e.Status.ToString();
            IsRunning = e.Status == Core.Server.ServerStatus.Running;
            EndpointUrl = _controller.EndpointUrl ?? "-";
        });

    private void OnServerLog(object? sender, LogEventArgs e) =>
        RunOnUi(() => AppendLog(e.Message));

    private void OnAudited(object? sender, WriteAuditEntry entry) =>
        RunOnUi(() =>
        {
            AuditEntries.Insert(0, entry);

            while (AuditEntries.Count > 200)
            {
                AuditEntries.RemoveAt(AuditEntries.Count - 1);
            }

            if (entry.Accepted)
            {
                AcceptedWrites++;
            }
            else
            {
                RejectedWrites++;
            }
        });

    private void AppendLog(string message)
    {
        LogEntries.Insert(0, $"{DateTime.Now:HH:mm:ss}  {message}");

        while (LogEntries.Count > 500)
        {
            LogEntries.RemoveAt(LogEntries.Count - 1);
        }
    }

    /// <summary>
    /// Server and coordinator events arrive on background threads; marshal to the UI thread.
    /// </summary>
    private void RunOnUi(Action action)
    {
        if (_dispatcher.CheckAccess())
        {
            action();
        }
        else
        {
            _dispatcher.BeginInvoke(action);
        }
    }

    public void Dispose()
    {
        _refreshTimer.Stop();
        _controller.Log -= OnServerLog;
        _controller.StatusChanged -= OnServerStatusChanged;
        _coordinator.Audited -= OnAudited;
        _ = _controller.StopAsync();
    }
}
