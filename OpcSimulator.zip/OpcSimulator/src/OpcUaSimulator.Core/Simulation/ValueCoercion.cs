using System.Globalization;
using OpcUaSimulator.Core.Model;

namespace OpcUaSimulator.Core.Simulation;

/// <summary>
/// Converts between the simulator's <see cref="SimDataType"/> and CLR values.
/// Client writes arrive as arbitrary boxed objects, so coercion must be explicit
/// and must fail cleanly rather than throwing into the OPC UA stack.
/// </summary>
public static class ValueCoercion
{
    /// <summary>Maps a <see cref="SimDataType"/> to its CLR type.</summary>
    public static Type ToClrType(SimDataType dataType) => dataType switch
    {
        SimDataType.Double => typeof(double),
        SimDataType.Float => typeof(float),
        SimDataType.Int32 => typeof(int),
        SimDataType.Int64 => typeof(long),
        SimDataType.Boolean => typeof(bool),
        SimDataType.String => typeof(string),
        _ => throw new NotSupportedException($"Unsupported data type '{dataType}'.")
    };

    /// <summary>Converts a generated double into the tag's declared CLR type.</summary>
    public static object FromDouble(double value, SimDataType dataType) => dataType switch
    {
        SimDataType.Double => value,
        SimDataType.Float => (float)value,
        SimDataType.Int32 => (int)Math.Round(value, MidpointRounding.AwayFromZero),
        SimDataType.Int64 => (long)Math.Round(value, MidpointRounding.AwayFromZero),
        SimDataType.Boolean => value >= 0.5d,
        SimDataType.String => value.ToString(CultureInfo.InvariantCulture),
        _ => throw new NotSupportedException($"Unsupported data type '{dataType}'.")
    };

    /// <summary>
    /// Attempts to convert an incoming client value to the tag's declared type.
    /// Returns false on type mismatch instead of throwing.
    /// </summary>
    public static bool TryCoerce(object? input, SimDataType dataType, out object? coerced)
    {
        coerced = null;

        if (input is null)
        {
            return false;
        }

        try
        {
            coerced = dataType switch
            {
                SimDataType.Double => Convert.ToDouble(input, CultureInfo.InvariantCulture),
                SimDataType.Float => Convert.ToSingle(input, CultureInfo.InvariantCulture),
                SimDataType.Int32 => Convert.ToInt32(input, CultureInfo.InvariantCulture),
                SimDataType.Int64 => Convert.ToInt64(input, CultureInfo.InvariantCulture),
                SimDataType.Boolean => CoerceBoolean(input),
                SimDataType.String => Convert.ToString(input, CultureInfo.InvariantCulture) ?? string.Empty,
                _ => throw new NotSupportedException($"Unsupported data type '{dataType}'.")
            };

            return true;
        }
        catch (Exception ex) when (ex is InvalidCastException or FormatException or OverflowException or ArgumentException)
        {
            coerced = null;
            return false;
        }
    }

    /// <summary>
    /// Converts a coerced value to a double for range checking.
    /// Booleans and strings are not range-checked, so they return false.
    /// </summary>
    public static bool TryGetNumeric(object? value, out double numeric)
    {
        switch (value)
        {
            case double d:
                numeric = d;
                return true;
            case float f:
                numeric = f;
                return true;
            case int i:
                numeric = i;
                return true;
            case long l:
                numeric = l;
                return true;
            default:
                numeric = 0d;
                return false;
        }
    }

    private static bool CoerceBoolean(object input) => input switch
    {
        bool b => b,
        string s when bool.TryParse(s, out var parsed) => parsed,
        string s when double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var numeric) => numeric >= 0.5d,
        _ => Convert.ToDouble(input, CultureInfo.InvariantCulture) >= 0.5d
    };
}
