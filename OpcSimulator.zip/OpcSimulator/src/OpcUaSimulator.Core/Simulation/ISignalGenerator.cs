using OpcUaSimulator.Core.Model;

namespace OpcUaSimulator.Core.Simulation;

/// <summary>
/// Produces the next raw value for a simulated tag.
/// </summary>
public interface ISignalGenerator
{
    /// <summary>
    /// Computes the value for the given elapsed time since the simulation started.
    /// Implementations must be deterministic for a given <paramref name="elapsed"/>
    /// unless they are explicitly stateful (RandomWalk, Counter).
    /// </summary>
    double Next(TimeSpan elapsed);

    /// <summary>Resets any accumulated state.</summary>
    void Reset();
}
