using OpcUaSimulator.Core.Model;

namespace OpcUaSimulator.Core.Simulation;

/// <summary>
/// Mutable runtime state for one simulated tag. All access is guarded by
/// <see cref="WriteCoordinator"/>; this type performs no locking of its own.
/// </summary>
public sealed class TagRuntime
{
    public TagRuntime(SimTag tag)
    {
        Tag = tag ?? throw new ArgumentNullException(nameof(tag));
        Generator = SignalGeneratorFactory.Create(tag);
        Value = ValueCoercion.FromDouble(tag.InitialValue, tag.DataType);
        SourceTimestampUtc = DateTime.UtcNow;
    }

    public SimTag Tag { get; }

    public ISignalGenerator Generator { get; private set; }

    public object? Value { get; set; }

    public DateTime SourceTimestampUtc { get; set; }

    /// <summary>UTC instant at which a Hybrid client override expires. Null when not overridden.</summary>
    public DateTime? OverrideExpiresUtc { get; set; }

    /// <summary>True when the value is pinned by the UI (fault injection).</summary>
    public bool IsFrozen { get; set; }

    public QualityOverride QualityOverride { get; set; }

    /// <summary>
    /// True when a connected client currently owns this value and the generator must not run.
    /// </summary>
    public bool IsClientControlled(DateTime nowUtc) => Tag.ControlMode switch
    {
        ControlMode.Setpoint => true,
        ControlMode.Hybrid => OverrideExpiresUtc.HasValue && OverrideExpiresUtc.Value > nowUtc,
        _ => false
    };

    /// <summary>Rebuilds the generator, e.g. after the tag definition was edited.</summary>
    public void RebuildGenerator() => Generator = SignalGeneratorFactory.Create(Tag);
}
