using System.Collections.Concurrent;
using Opc.Ua;
using OpcUaSimulator.Core.Model;

namespace OpcUaSimulator.Core.Simulation;

/// <summary>
/// Outcome of a mutation attempt.
/// </summary>
public readonly record struct WriteOutcome(bool Accepted, uint StatusCode, string? Message)
{
    public static WriteOutcome Ok() => new(true, StatusCodes.Good, null);

    public static WriteOutcome Fail(uint statusCode, string message) => new(false, statusCode, message);
}

/// <summary>
/// The single, thread-safe entry point for every value mutation in the simulator:
/// simulation ticks, client writes, method handlers and UI overrides all funnel through here.
///
/// This exists because client writes arrive on OPC UA server worker threads while the
/// simulation engine writes on its own timer thread; without a single guarded path the
/// two race and produce torn values.
/// </summary>
public sealed class WriteCoordinator
{
    private readonly Lock _gate = new();
    private readonly Dictionary<string, TagRuntime> _tags = new(StringComparer.Ordinal);
    private readonly ConcurrentQueue<WriteAuditEntry> _audit = new();
    private readonly int _auditCapacity;

    public WriteCoordinator(int auditCapacity = 1000) => _auditCapacity = auditCapacity;

    /// <summary>Master kill switch: when false every client write is rejected.</summary>
    public bool AllowClientWrites { get; set; } = true;

    /// <summary>Fault injection: when true every client write is rejected with BadUserAccessDenied.</summary>
    public bool RejectAllWrites { get; set; }

    /// <summary>Raised after a value actually changes so the node manager can push a data change.</summary>
    public event EventHandler<TagValueChangedEventArgs>? ValueChanged;

    /// <summary>Raised for every write/command attempt, accepted or rejected.</summary>
    public event EventHandler<WriteAuditEntry>? Audited;

    public IReadOnlyCollection<WriteAuditEntry> AuditEntries => _audit.ToArray();

    public void LoadTags(IEnumerable<SimTag> tags)
    {
        ArgumentNullException.ThrowIfNull(tags);

        lock (_gate)
        {
            _tags.Clear();
            foreach (var tag in tags)
            {
                _tags[tag.NodeId] = new TagRuntime(tag);
            }
        }
    }

    public IReadOnlyList<TagRuntime> Snapshot()
    {
        lock (_gate)
        {
            return [.. _tags.Values];
        }
    }

    public bool TryGetRuntime(string nodeId, out TagRuntime? runtime)
    {
        lock (_gate)
        {
            var found = _tags.TryGetValue(nodeId, out var value);
            runtime = value;
            return found;
        }
    }

    /// <summary>
    /// Advances every tag not currently under client control. Called by the simulation engine.
    /// </summary>
    public void Tick(TimeSpan elapsed)
    {
        var nowUtc = DateTime.UtcNow;
        List<TagValueChangedEventArgs> changes = [];

        lock (_gate)
        {
            foreach (var runtime in _tags.Values)
            {
                if (runtime.IsFrozen || runtime.IsClientControlled(nowUtc))
                {
                    continue;
                }

                // A Hybrid hold that has just expired: clear it so the generator resumes cleanly.
                if (runtime.OverrideExpiresUtc.HasValue && runtime.OverrideExpiresUtc.Value <= nowUtc)
                {
                    runtime.OverrideExpiresUtc = null;
                }

                var raw = runtime.Generator.Next(elapsed);
                var newValue = ValueCoercion.FromDouble(raw, runtime.Tag.DataType);

                if (Equals(runtime.Value, newValue))
                {
                    continue;
                }

                runtime.Value = newValue;
                runtime.SourceTimestampUtc = nowUtc;
                changes.Add(new TagValueChangedEventArgs(runtime.Tag.NodeId, newValue, ResolveStatus(runtime), nowUtc));
            }
        }

        // Raise events outside the lock: handlers call into the OPC UA stack.
        foreach (var change in changes)
        {
            ValueChanged?.Invoke(this, change);
        }
    }

    /// <summary>
    /// Applies a client write through the full validation ladder.
    /// </summary>
    /// <param name="nodeId">Tag identifier.</param>
    /// <param name="value">Raw value supplied by the client.</param>
    /// <param name="identity">Session/user name for auditing.</param>
    /// <param name="hasWriteRole">False for anonymous/read-only sessions.</param>
    /// <param name="source">Distinguishes a direct write from a method-driven one.</param>
    public WriteOutcome ApplyClientWrite(
        string nodeId,
        object? value,
        string identity,
        bool hasWriteRole,
        WriteSource source = WriteSource.ClientWrite)
    {
        TagValueChangedEventArgs? change = null;
        WriteOutcome outcome;
        object? oldValue = null;

        lock (_gate)
        {
            if (!_tags.TryGetValue(nodeId, out var runtime))
            {
                outcome = WriteOutcome.Fail(StatusCodes.BadNodeIdUnknown, $"Unknown node '{nodeId}'.");
            }
            else
            {
                oldValue = runtime.Value;
                outcome = Validate(runtime, value, hasWriteRole, out var coerced);

                if (outcome.Accepted)
                {
                    var nowUtc = DateTime.UtcNow;
                    runtime.Value = coerced;
                    runtime.SourceTimestampUtc = nowUtc;

                    // Hybrid tags suppress the generator for HoldSeconds; Setpoint tags hold indefinitely.
                    if (runtime.Tag.ControlMode == ControlMode.Hybrid)
                    {
                        runtime.OverrideExpiresUtc = nowUtc.AddSeconds(runtime.Tag.HoldSeconds);
                    }

                    change = new TagValueChangedEventArgs(nodeId, coerced, ResolveStatus(runtime), nowUtc);
                }
            }
        }

        RecordAudit(new WriteAuditEntry
        {
            Source = source,
            Identity = identity,
            NodeId = nodeId,
            OldValue = oldValue,
            NewValue = value,
            StatusCode = outcome.StatusCode,
            Accepted = outcome.Accepted,
            Message = outcome.Message
        });

        if (change is not null)
        {
            ValueChanged?.Invoke(this, change);
        }

        return outcome;
    }

    /// <summary>
    /// The validation ladder. Order matters: permission and writability are checked
    /// before type/range so a read-only tag never leaks range information.
    /// </summary>
    private WriteOutcome Validate(TagRuntime runtime, object? value, bool hasWriteRole, out object? coerced)
    {
        coerced = null;

        if (!AllowClientWrites)
        {
            return WriteOutcome.Fail(StatusCodes.BadUserAccessDenied, "Client writes are disabled on the simulator.");
        }

        if (RejectAllWrites)
        {
            return WriteOutcome.Fail(StatusCodes.BadUserAccessDenied, "Write rejection fault injection is active.");
        }

        if (!hasWriteRole)
        {
            return WriteOutcome.Fail(StatusCodes.BadUserAccessDenied, "Session does not hold the write role.");
        }

        if (!runtime.Tag.IsWritable)
        {
            return WriteOutcome.Fail(
                StatusCodes.BadNotWritable,
                $"Tag '{runtime.Tag.NodeId}' is {runtime.Tag.ControlMode} and does not accept writes.");
        }

        if (!ValueCoercion.TryCoerce(value, runtime.Tag.DataType, out coerced))
        {
            return WriteOutcome.Fail(
                StatusCodes.BadTypeMismatch,
                $"Value '{value}' cannot be converted to {runtime.Tag.DataType}.");
        }

        // Range only applies to numeric types; booleans and strings are unconstrained.
        if (ValueCoercion.TryGetNumeric(coerced, out var numeric) &&
            (numeric < runtime.Tag.Min || numeric > runtime.Tag.Max))
        {
            coerced = null;
            return WriteOutcome.Fail(
                StatusCodes.BadOutOfRange,
                $"Value {numeric} is outside the range [{runtime.Tag.Min}, {runtime.Tag.Max}].");
        }

        return WriteOutcome.Ok();
    }

    /// <summary>Sets a value from the UI, bypassing client permission checks.</summary>
    public WriteOutcome ApplyUiOverride(string nodeId, object? value)
    {
        TagValueChangedEventArgs? change = null;
        WriteOutcome outcome;

        lock (_gate)
        {
            if (!_tags.TryGetValue(nodeId, out var runtime))
            {
                outcome = WriteOutcome.Fail(StatusCodes.BadNodeIdUnknown, $"Unknown node '{nodeId}'.");
            }
            else if (!ValueCoercion.TryCoerce(value, runtime.Tag.DataType, out var coerced))
            {
                outcome = WriteOutcome.Fail(StatusCodes.BadTypeMismatch, $"Value '{value}' is not a valid {runtime.Tag.DataType}.");
            }
            else
            {
                var nowUtc = DateTime.UtcNow;
                runtime.Value = coerced;
                runtime.SourceTimestampUtc = nowUtc;
                change = new TagValueChangedEventArgs(nodeId, coerced, ResolveStatus(runtime), nowUtc);
                outcome = WriteOutcome.Ok();
            }
        }

        RecordAudit(new WriteAuditEntry
        {
            Source = WriteSource.UiOverride,
            Identity = "ui",
            NodeId = nodeId,
            NewValue = value,
            StatusCode = outcome.StatusCode,
            Accepted = outcome.Accepted,
            Message = outcome.Message
        });

        if (change is not null)
        {
            ValueChanged?.Invoke(this, change);
        }

        return outcome;
    }

    public void SetQualityOverride(string nodeId, QualityOverride quality)
    {
        TagValueChangedEventArgs? change = null;

        lock (_gate)
        {
            if (_tags.TryGetValue(nodeId, out var runtime))
            {
                runtime.QualityOverride = quality;
                change = new TagValueChangedEventArgs(nodeId, runtime.Value, ResolveStatus(runtime), DateTime.UtcNow);
            }
        }

        if (change is not null)
        {
            ValueChanged?.Invoke(this, change);
        }
    }

    public void SetFrozen(string nodeId, bool frozen)
    {
        lock (_gate)
        {
            if (_tags.TryGetValue(nodeId, out var runtime))
            {
                runtime.IsFrozen = frozen;
            }
        }
    }

    /// <summary>Fault injection: pushes the value to a multiple of the configured range.</summary>
    public void InjectSpike(string nodeId, double multiplier = 1.5d)
    {
        TagValueChangedEventArgs? change = null;

        lock (_gate)
        {
            if (_tags.TryGetValue(nodeId, out var runtime) &&
                ValueCoercion.TryGetNumeric(runtime.Value, out var current))
            {
                // Deliberately not clamped: a spike must be able to exceed the normal range.
                var spiked = ValueCoercion.FromDouble(current * multiplier, runtime.Tag.DataType);
                runtime.Value = spiked;
                runtime.SourceTimestampUtc = DateTime.UtcNow;
                change = new TagValueChangedEventArgs(nodeId, spiked, ResolveStatus(runtime), runtime.SourceTimestampUtc);
            }
        }

        if (change is not null)
        {
            ValueChanged?.Invoke(this, change);
        }
    }

    /// <summary>Clears any client override so the generator immediately resumes.</summary>
    public void ReleaseOverride(string nodeId)
    {
        lock (_gate)
        {
            if (_tags.TryGetValue(nodeId, out var runtime))
            {
                runtime.OverrideExpiresUtc = null;
            }
        }
    }

    public void RecordAudit(WriteAuditEntry entry)
    {
        _audit.Enqueue(entry);

        while (_audit.Count > _auditCapacity && _audit.TryDequeue(out _))
        {
            // Bounded ring buffer: drop oldest.
        }

        Audited?.Invoke(this, entry);
    }

    private static uint ResolveStatus(TagRuntime runtime) => runtime.QualityOverride switch
    {
        QualityOverride.Bad => StatusCodes.Bad,
        QualityOverride.Uncertain => StatusCodes.Uncertain,
        _ => StatusCodes.Good
    };
}

/// <summary>Payload describing a committed value change.</summary>
public sealed class TagValueChangedEventArgs(string nodeId, object? value, uint statusCode, DateTime sourceTimestampUtc)
    : EventArgs
{
    public string NodeId { get; } = nodeId;

    public object? Value { get; } = value;

    public uint StatusCode { get; } = statusCode;

    public DateTime SourceTimestampUtc { get; } = sourceTimestampUtc;
}
