using OpcUaSimulator.Core.Model;

namespace OpcUaSimulator.Core.Simulation;

/// <summary>
/// Shared behaviour for generators: range clamping and optional noise.
/// Noise uses a per-generator <see cref="Random"/> instance because <see cref="Random.Shared"/>
/// would make deterministic unit testing impossible.
/// </summary>
public abstract class SignalGeneratorBase(SimTag tag) : ISignalGenerator
{
    protected SimTag Tag { get; } = tag ?? throw new ArgumentNullException(nameof(tag));

    private readonly Random _random = new(tag.NodeId.GetHashCode(StringComparison.Ordinal));

    protected double Range => Tag.Max - Tag.Min;

    /// <summary>Period in seconds, guarded against zero/negative to avoid divide-by-zero.</summary>
    protected double PeriodSeconds => Tag.PeriodMs > 0 ? Tag.PeriodMs / 1000d : 1d;

    public double Next(TimeSpan elapsed)
    {
        var value = Generate(elapsed);
        value = ApplyNoise(value);
        return Clamp(value);
    }

    public virtual void Reset()
    {
    }

    protected abstract double Generate(TimeSpan elapsed);

    private double ApplyNoise(double value)
    {
        if (Tag.NoisePercent <= 0d)
        {
            return value;
        }

        // Symmetric noise band: +/- (NoisePercent% of the full range) / 2.
        var amplitude = Range * (Tag.NoisePercent / 100d);
        var offset = (_random.NextDouble() - 0.5d) * amplitude;
        return value + offset;
    }

    protected double Clamp(double value) => Math.Clamp(value, Tag.Min, Tag.Max);
}

/// <summary>Holds a fixed value.</summary>
public sealed class ConstantGenerator(SimTag tag) : SignalGeneratorBase(tag)
{
    protected override double Generate(TimeSpan elapsed) => Tag.InitialValue;
}

/// <summary>Linear sawtooth from Min to Max over one period.</summary>
public sealed class RampGenerator(SimTag tag) : SignalGeneratorBase(tag)
{
    protected override double Generate(TimeSpan elapsed)
    {
        var phase = elapsed.TotalSeconds % PeriodSeconds / PeriodSeconds;
        return Tag.Min + (Range * phase);
    }
}

/// <summary>Sine wave spanning the full Min..Max range.</summary>
public sealed class SineGenerator(SimTag tag) : SignalGeneratorBase(tag)
{
    protected override double Generate(TimeSpan elapsed)
    {
        var phase = 2d * Math.PI * elapsed.TotalSeconds / PeriodSeconds;
        var normalized = (Math.Sin(phase) + 1d) / 2d;
        return Tag.Min + (Range * normalized);
    }
}

/// <summary>Alternates between Min and Max each half period.</summary>
public sealed class SquareGenerator(SimTag tag) : SignalGeneratorBase(tag)
{
    protected override double Generate(TimeSpan elapsed)
    {
        var phase = elapsed.TotalSeconds % PeriodSeconds / PeriodSeconds;
        return phase < 0.5d ? Tag.Min : Tag.Max;
    }
}

/// <summary>Stateful random walk that drifts within the configured range.</summary>
public sealed class RandomWalkGenerator : SignalGeneratorBase
{
    private readonly Random _walkRandom;
    private double _current;

    public RandomWalkGenerator(SimTag tag) : base(tag)
    {
        _walkRandom = new Random(tag.NodeId.GetHashCode(StringComparison.Ordinal) ^ 0x5F3759DF);
        _current = Clamp(tag.InitialValue);
    }

    protected override double Generate(TimeSpan elapsed)
    {
        // Step is 2% of the range per tick, centred on zero.
        var step = (_walkRandom.NextDouble() - 0.5d) * Range * 0.04d;
        _current = Clamp(_current + step);
        return _current;
    }

    public override void Reset() => _current = Clamp(Tag.InitialValue);
}

/// <summary>Monotonically increasing counter that wraps at Max back to Min.</summary>
public sealed class CounterGenerator : SignalGeneratorBase
{
    private double _current;

    public CounterGenerator(SimTag tag) : base(tag) => _current = Clamp(tag.InitialValue);

    protected override double Generate(TimeSpan elapsed)
    {
        // One full sweep of the range per period.
        var increment = Range > 0d ? Range / Math.Max(PeriodSeconds, 1d) : 1d;
        _current += increment;

        if (_current > Tag.Max)
        {
            _current = Tag.Min;
        }

        return _current;
    }

    public override void Reset() => _current = Clamp(Tag.InitialValue);
}

/// <summary>Boolean flip-flop: 0 for the first half period, 1 for the second.</summary>
public sealed class BooleanToggleGenerator(SimTag tag) : SignalGeneratorBase(tag)
{
    protected override double Generate(TimeSpan elapsed)
    {
        var phase = elapsed.TotalSeconds % PeriodSeconds / PeriodSeconds;
        return phase < 0.5d ? 0d : 1d;
    }
}

/// <summary>Creates the generator matching a tag's <see cref="SignalType"/>.</summary>
public static class SignalGeneratorFactory
{
    public static ISignalGenerator Create(SimTag tag)
    {
        ArgumentNullException.ThrowIfNull(tag);

        return tag.SignalType switch
        {
            SignalType.Constant => new ConstantGenerator(tag),
            SignalType.Ramp => new RampGenerator(tag),
            SignalType.Sine => new SineGenerator(tag),
            SignalType.Square => new SquareGenerator(tag),
            SignalType.RandomWalk => new RandomWalkGenerator(tag),
            SignalType.Counter => new CounterGenerator(tag),
            SignalType.BooleanToggle => new BooleanToggleGenerator(tag),
            _ => throw new NotSupportedException($"Unsupported signal type '{tag.SignalType}'.")
        };
    }
}
