using System.Diagnostics;

namespace OpcUaSimulator.Core.Simulation;

/// <summary>
/// Drives the simulation by ticking the <see cref="WriteCoordinator"/> on a periodic timer.
///
/// Uses a single timer with re-entrancy protection: if a tick overruns the interval the
/// next one is skipped rather than queued, which prevents unbounded thread pileup on slow machines.
/// </summary>
public sealed class SimulationEngine : IDisposable
{
    private readonly WriteCoordinator _coordinator;
    private readonly Stopwatch _clock = new();
    private readonly Lock _gate = new();
    private Timer? _timer;
    private int _tickInProgress;
    private bool _disposed;

    public SimulationEngine(WriteCoordinator coordinator, int intervalMs = 1000)
    {
        _coordinator = coordinator ?? throw new ArgumentNullException(nameof(coordinator));
        IntervalMs = Math.Max(50, intervalMs);
    }

    public int IntervalMs { get; private set; }

    public bool IsRunning { get; private set; }

    /// <summary>Raised when a tick throws, so the UI can surface simulation faults.</summary>
    public event EventHandler<Exception>? TickFaulted;

    public void Start()
    {
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);

            if (IsRunning)
            {
                return;
            }

            _clock.Start();
            _timer = new Timer(OnTick, state: null, dueTime: 0, period: IntervalMs);
            IsRunning = true;
        }
    }

    public void Stop()
    {
        lock (_gate)
        {
            if (!IsRunning)
            {
                return;
            }

            _timer?.Dispose();
            _timer = null;
            _clock.Stop();
            IsRunning = false;
        }
    }

    /// <summary>Changes the tick interval, restarting the timer if it is running.</summary>
    public void SetInterval(int intervalMs)
    {
        lock (_gate)
        {
            IntervalMs = Math.Max(50, intervalMs);

            if (IsRunning)
            {
                _timer?.Change(dueTime: 0, period: IntervalMs);
            }
        }
    }

    private void OnTick(object? state)
    {
        // Skip this tick if the previous one is still running.
        if (Interlocked.Exchange(ref _tickInProgress, 1) == 1)
        {
            return;
        }

        try
        {
            _coordinator.Tick(_clock.Elapsed);
        }
        catch (Exception ex)
        {
            TickFaulted?.Invoke(this, ex);
        }
        finally
        {
            Interlocked.Exchange(ref _tickInProgress, 0);
        }
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        Stop();
        _disposed = true;
    }
}
