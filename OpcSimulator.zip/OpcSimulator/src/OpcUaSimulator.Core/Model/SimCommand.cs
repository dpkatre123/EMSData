namespace OpcUaSimulator.Core.Model;

/// <summary>
/// Declared argument of a <see cref="SimCommand"/>.
/// </summary>
public sealed class SimArgument
{
    public string Name { get; set; } = string.Empty;

    public SimDataType DataType { get; set; } = SimDataType.String;

    public string? Description { get; set; }
}

/// <summary>
/// Definition of an OPC UA Method node that clients can invoke.
/// </summary>
public sealed class SimCommand
{
    public string NodeId { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }

    /// <summary>
    /// Key selecting the built-in handler implementation, e.g. "OpenBreaker" or "ResetEnergyCounter".
    /// </summary>
    public string HandlerKey { get; set; } = string.Empty;

    public List<SimArgument> InputArguments { get; set; } = [];

    public List<SimArgument> OutputArguments { get; set; } = [];
}
