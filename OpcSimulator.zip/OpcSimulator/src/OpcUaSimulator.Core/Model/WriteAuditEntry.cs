namespace OpcUaSimulator.Core.Model;

/// <summary>
/// Origin of a value mutation, used for auditing.
/// </summary>
public enum WriteSource
{
    Generator,
    ClientWrite,
    ClientMethod,
    UiOverride
}

/// <summary>
/// Immutable record of an attempted write or command invocation.
/// </summary>
public sealed class WriteAuditEntry
{
    public DateTime TimestampUtc { get; init; } = DateTime.UtcNow;

    public WriteSource Source { get; init; }

    /// <summary>Session/user that initiated the write, or "-" for internal sources.</summary>
    public string Identity { get; init; } = "-";

    public string NodeId { get; init; } = string.Empty;

    public object? OldValue { get; init; }

    public object? NewValue { get; init; }

    /// <summary>Numeric OPC UA status code returned to the caller.</summary>
    public uint StatusCode { get; init; }

    public bool Accepted { get; init; }

    /// <summary>Human-readable reason, populated on rejection.</summary>
    public string? Message { get; init; }
}
