namespace OpcUaSimulator.Core.Model;

/// <summary>
/// Definition of a single simulated OPC UA point (Variable node).
/// </summary>
public sealed class SimTag
{
    /// <summary>Identifier string used for the NodeId (namespace index is applied by the node manager).</summary>
    public string NodeId { get; set; } = string.Empty;

    /// <summary>Display/browse name of the variable node.</summary>
    public string BrowseName { get; set; } = string.Empty;

    /// <summary>Slash-delimited folder path under the Objects folder, e.g. "Plant/Meter01".</summary>
    public string FolderPath { get; set; } = string.Empty;

    public SimDataType DataType { get; set; } = SimDataType.Double;

    public SignalType SignalType { get; set; } = SignalType.Constant;

    public ControlMode ControlMode { get; set; } = ControlMode.Simulated;

    public double Min { get; set; }

    public double Max { get; set; } = 100d;

    /// <summary>Waveform period in milliseconds. Must be greater than zero for periodic signals.</summary>
    public int PeriodMs { get; set; } = 10_000;

    /// <summary>Random noise applied to the generated value, as a percentage of (Max - Min).</summary>
    public double NoisePercent { get; set; }

    /// <summary>For <see cref="ControlMode.Hybrid"/>: how long a client write suppresses the generator.</summary>
    public double HoldSeconds { get; set; } = 30d;

    public QualityOverride QualityOverride { get; set; } = QualityOverride.None;

    /// <summary>Engineering unit shown in the UI (informational only).</summary>
    public string? Unit { get; set; }

    /// <summary>Initial/default value applied before the first generator tick.</summary>
    public double InitialValue { get; set; }

    /// <summary>True when clients are permitted to write this tag.</summary>
    public bool IsWritable => ControlMode is ControlMode.Setpoint or ControlMode.Hybrid;

    public SimTag Clone() => (SimTag)MemberwiseClone();
}
