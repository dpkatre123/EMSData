namespace OpcUaSimulator.Core.Model;

/// <summary>
/// Waveform used to drive a simulated tag value.
/// </summary>
public enum SignalType
{
    Constant,
    Ramp,
    Sine,
    Square,
    RandomWalk,
    Counter,
    BooleanToggle
}

/// <summary>
/// Determines who owns a tag's value: the simulation engine, a connected client, or both.
/// </summary>
public enum ControlMode
{
    /// <summary>Generator owns the value. Client writes are rejected with BadNotWritable.</summary>
    Simulated,

    /// <summary>Client owns the value. No generator runs; the written value persists.</summary>
    Setpoint,

    /// <summary>A client write overrides the generator for <see cref="SimTag.HoldSeconds"/>, then simulation resumes.</summary>
    Hybrid
}

/// <summary>
/// Optional quality override used for fault-injection testing.
/// </summary>
public enum QualityOverride
{
    None,
    Bad,
    Uncertain
}

/// <summary>
/// Supported value types for a simulated point.
/// </summary>
public enum SimDataType
{
    Double,
    Float,
    Int32,
    Int64,
    Boolean,
    String
}
