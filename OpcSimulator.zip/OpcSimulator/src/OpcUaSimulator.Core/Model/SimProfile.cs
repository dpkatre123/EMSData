namespace OpcUaSimulator.Core.Model;

/// <summary>
/// A complete simulation scenario: the set of tags and commands exposed by the server.
/// </summary>
public sealed class SimProfile
{
    public string Name { get; set; } = "Untitled";

    public string? Description { get; set; }

    /// <summary>Namespace URI used for all custom nodes in this profile.</summary>
    public string NamespaceUri { get; set; } = "http://ges.com/OpcUaSimulator";

    /// <summary>Simulation engine tick interval in milliseconds.</summary>
    public int UpdateIntervalMs { get; set; } = 1000;

    public List<SimTag> Tags { get; set; } = [];

    public List<SimCommand> Commands { get; set; } = [];
}
