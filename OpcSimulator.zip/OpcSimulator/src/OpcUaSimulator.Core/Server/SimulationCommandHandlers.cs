using System.Globalization;
using Opc.Ua;
using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.Core.Server;

/// <summary>
/// Implements the built-in OPC UA command methods. Every state change is routed through
/// <see cref="WriteCoordinator"/> so commands obey the same locking and auditing rules as writes.
/// </summary>
public sealed class SimulationCommandHandlers(WriteCoordinator coordinator)
{
    private readonly WriteCoordinator _coordinator = coordinator;

    /// <summary>Raised when a command asks the host to start or stop the simulation engine.</summary>
    public event EventHandler<bool>? SimulationRunRequested;

    public ServiceResult Invoke(
        string handlerKey,
        string identity,
        bool hasWriteRole,
        IList<object> inputs,
        IList<object> outputs)
    {
        // Commands mutate state, so they require the same privilege as a write.
        if (!hasWriteRole)
        {
            return Respond(outputs, false, "Session does not hold the write role.",
                StatusCodes.BadUserAccessDenied, handlerKey, identity, inputs);
        }

        if (_coordinator.RejectAllWrites || !_coordinator.AllowClientWrites)
        {
            return Respond(outputs, false, "Writes are currently disabled on the simulator.",
                StatusCodes.BadUserAccessDenied, handlerKey, identity, inputs);
        }

        try
        {
            return handlerKey switch
            {
                "OpenBreaker" => SetBoolean(inputs, outputs, identity, value: true, handlerKey),
                "CloseBreaker" => SetBoolean(inputs, outputs, identity, value: false, handlerKey),
                "SetActivePowerLimit" => SetNumeric(inputs, outputs, identity, handlerKey),
                "ResetEnergyCounter" => ResetCounter(inputs, outputs, identity, handlerKey),
                "StartSimulation" => ToggleSimulation(outputs, identity, run: true, handlerKey, inputs),
                "StopSimulation" => ToggleSimulation(outputs, identity, run: false, handlerKey, inputs),
                "InjectFault" => InjectFault(inputs, outputs, identity, handlerKey),
                _ => Respond(outputs, false, $"Unknown command handler '{handlerKey}'.",
                        StatusCodes.BadNotImplemented, handlerKey, identity, inputs)
            };
        }
        catch (Exception ex)
        {
            return Respond(outputs, false, $"Command failed: {ex.Message}",
                StatusCodes.BadInternalError, handlerKey, identity, inputs);
        }
    }

    private ServiceResult SetBoolean(
        IList<object> inputs, IList<object> outputs, string identity, bool value, string handlerKey)
    {
        if (!TryGetString(inputs, 0, out var nodeId))
        {
            return Respond(outputs, false, "Expected a target node id as the first argument.",
                StatusCodes.BadArgumentsMissing, handlerKey, identity, inputs);
        }

        var outcome = _coordinator.ApplyClientWrite(nodeId, value, identity, hasWriteRole: true, WriteSource.ClientMethod);

        return Respond(outputs, outcome.Accepted,
            outcome.Accepted ? $"{nodeId} set to {value}." : outcome.Message ?? "Rejected.",
            outcome.StatusCode, handlerKey, identity, inputs, audit: false);
    }

    private ServiceResult SetNumeric(
        IList<object> inputs, IList<object> outputs, string identity, string handlerKey)
    {
        if (!TryGetString(inputs, 0, out var nodeId))
        {
            return Respond(outputs, false, "Expected a target node id as the first argument.",
                StatusCodes.BadArgumentsMissing, handlerKey, identity, inputs);
        }

        if (inputs.Count < 2)
        {
            return Respond(outputs, false, "Expected a numeric value as the second argument.",
                StatusCodes.BadArgumentsMissing, handlerKey, identity, inputs);
        }

        var outcome = _coordinator.ApplyClientWrite(nodeId, inputs[1], identity, hasWriteRole: true, WriteSource.ClientMethod);

        return Respond(outputs, outcome.Accepted,
            outcome.Accepted ? $"{nodeId} set to {inputs[1]}." : outcome.Message ?? "Rejected.",
            outcome.StatusCode, handlerKey, identity, inputs, audit: false);
    }

    private ServiceResult ResetCounter(
        IList<object> inputs, IList<object> outputs, string identity, string handlerKey)
    {
        if (!TryGetString(inputs, 0, out var nodeId))
        {
            return Respond(outputs, false, "Expected a target node id as the first argument.",
                StatusCodes.BadArgumentsMissing, handlerKey, identity, inputs);
        }

        if (!_coordinator.TryGetRuntime(nodeId, out var runtime) || runtime is null)
        {
            return Respond(outputs, false, $"Unknown node '{nodeId}'.",
                StatusCodes.BadNodeIdUnknown, handlerKey, identity, inputs);
        }

        // Reset bypasses ControlMode: resetting a Simulated counter is a legitimate operation.
        _coordinator.ApplyUiOverride(nodeId, runtime.Tag.Min);
        runtime.Generator.Reset();
        _coordinator.ReleaseOverride(nodeId);

        return Respond(outputs, true, $"{nodeId} reset to {runtime.Tag.Min}.",
            StatusCodes.Good, handlerKey, identity, inputs);
    }

    private ServiceResult ToggleSimulation(
        IList<object> outputs, string identity, bool run, string handlerKey, IList<object> inputs)
    {
        SimulationRunRequested?.Invoke(this, run);

        return Respond(outputs, true, run ? "Simulation started." : "Simulation stopped.",
            StatusCodes.Good, handlerKey, identity, inputs);
    }

    private ServiceResult InjectFault(
        IList<object> inputs, IList<object> outputs, string identity, string handlerKey)
    {
        if (!TryGetString(inputs, 0, out var nodeId))
        {
            return Respond(outputs, false, "Expected a target node id as the first argument.",
                StatusCodes.BadArgumentsMissing, handlerKey, identity, inputs);
        }

        if (!TryGetString(inputs, 1, out var faultType))
        {
            return Respond(outputs, false, "Expected a fault type as the second argument.",
                StatusCodes.BadArgumentsMissing, handlerKey, identity, inputs);
        }

        if (!_coordinator.TryGetRuntime(nodeId, out _))
        {
            return Respond(outputs, false, $"Unknown node '{nodeId}'.",
                StatusCodes.BadNodeIdUnknown, handlerKey, identity, inputs);
        }

        switch (faultType.ToLowerInvariant())
        {
            case "bad":
                _coordinator.SetQualityOverride(nodeId, QualityOverride.Bad);
                break;
            case "uncertain":
                _coordinator.SetQualityOverride(nodeId, QualityOverride.Uncertain);
                break;
            case "good":
            case "clear":
                _coordinator.SetQualityOverride(nodeId, QualityOverride.None);
                _coordinator.SetFrozen(nodeId, false);
                break;
            case "freeze":
                _coordinator.SetFrozen(nodeId, true);
                break;
            case "spike":
                _coordinator.InjectSpike(nodeId);
                break;
            default:
                return Respond(outputs, false,
                    $"Unknown fault type '{faultType}'. Expected: bad, uncertain, good, freeze, spike.",
                    StatusCodes.BadInvalidArgument, handlerKey, identity, inputs);
        }

        return Respond(outputs, true, $"Fault '{faultType}' applied to {nodeId}.",
            StatusCodes.Good, handlerKey, identity, inputs);
    }

    /// <summary>
    /// Fills the standard (success, message) output arguments and records an audit entry.
    /// </summary>
    private ServiceResult Respond(
        IList<object> outputs,
        bool success,
        string message,
        uint statusCode,
        string handlerKey,
        string identity,
        IList<object> inputs,
        bool audit = true)
    {
        if (outputs.Count > 0)
        {
            outputs[0] = success;
        }

        if (outputs.Count > 1)
        {
            outputs[1] = message;
        }

        if (audit)
        {
            _coordinator.RecordAudit(new WriteAuditEntry
            {
                Source = WriteSource.ClientMethod,
                Identity = identity,
                NodeId = handlerKey,
                NewValue = FormatInputs(inputs),
                StatusCode = statusCode,
                Accepted = success,
                Message = message
            });
        }

        // A failed command still returns Good at the service level when it reports
        // its failure through output arguments; only argument/permission faults are service errors.
        return statusCode == StatusCodes.Good
            ? ServiceResult.Good
            : new ServiceResult(statusCode, message);
    }

    private static string FormatInputs(IList<object> inputs) =>
        inputs.Count == 0 ? "-" : string.Join(", ", inputs.Select(i => Convert.ToString(i, CultureInfo.InvariantCulture)));

    private static bool TryGetString(IList<object> inputs, int index, out string value)
    {
        value = string.Empty;

        if (inputs.Count <= index || inputs[index] is null)
        {
            return false;
        }

        value = Convert.ToString(inputs[index], CultureInfo.InvariantCulture) ?? string.Empty;
        return !string.IsNullOrWhiteSpace(value);
    }
}
