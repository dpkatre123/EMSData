using Opc.Ua;
using Opc.Ua.Configuration;
using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.Core.Server;

public enum ServerStatus
{
    Stopped,
    Starting,
    Running,
    Faulted
}

public sealed class ServerStatusEventArgs(ServerStatus status, string? message = null) : EventArgs
{
    public ServerStatus Status { get; } = status;

    public string? Message { get; } = message;
}

public sealed class LogEventArgs(string message, bool isError = false) : EventArgs
{
    public DateTime TimestampUtc { get; } = DateTime.UtcNow;

    public string Message { get; } = message;

    public bool IsError { get; } = isError;
}

/// <summary>
/// Owns the OPC UA server lifecycle: configuration load, certificate bootstrap,
/// start/stop, and the simulation engine that drives tag values.
/// </summary>
public sealed class ServerController : IAsyncDisposable
{
    private readonly string _configFilePath;
    private ApplicationInstance? _application;
    private SimulationServer? _server;
    private SimulationEngine? _engine;

    public ServerController(WriteCoordinator coordinator, string configFilePath)
    {
        Coordinator = coordinator;
        _configFilePath = configFilePath;
    }

    public WriteCoordinator Coordinator { get; }

    public ServerStatus Status { get; private set; } = ServerStatus.Stopped;

    public SimProfile? Profile { get; private set; }

    /// <summary>Endpoint clients should connect to, available once running.</summary>
    public string? EndpointUrl { get; private set; }

    /// <summary>When true, untrusted client certificates are accepted (dev convenience).</summary>
    public bool AutoAcceptUntrustedCertificates { get; set; } = true;

    public event EventHandler<ServerStatusEventArgs>? StatusChanged;

    public event EventHandler<LogEventArgs>? Log;

    public async Task StartAsync(SimProfile profile, CancellationToken cancellationToken = default)
    {
        if (Status is ServerStatus.Running or ServerStatus.Starting)
        {
            OnLog("Server is already running.");
            return;
        }

        ArgumentNullException.ThrowIfNull(profile);

        try
        {
            SetStatus(ServerStatus.Starting);

            // Fail fast on a malformed profile rather than deep inside the node manager.
            Validation.ProfileValidator.Validate(profile).ThrowIfInvalid();

            Profile = profile;
            Coordinator.LoadTags(profile.Tags);

            _application = new ApplicationInstance(telemetry: null)
            {
                ApplicationName = "OPC UA Simulator",
                ApplicationType = ApplicationType.Server,
                ConfigSectionName = "Opc.Ua.Simulator"
            };

            OnLog($"Loading configuration from {_configFilePath}");
            var configuration = await _application.LoadApplicationConfigurationAsync(_configFilePath, silent: false)
                .ConfigureAwait(false);

            configuration.CertificateValidator.CertificateValidation += OnCertificateValidation;

            OnLog("Checking application certificate...");
            var certificateOk = await _application
                .CheckApplicationInstanceCertificatesAsync(silent: true, ct: cancellationToken)
                .ConfigureAwait(false);

            if (!certificateOk)
            {
                throw new InvalidOperationException(
                    "Application instance certificate is invalid and could not be created.");
            }

            cancellationToken.ThrowIfCancellationRequested();

            _server = new SimulationServer(profile, Coordinator);
            await _application.StartAsync(_server).ConfigureAwait(false);

            EndpointUrl = configuration.ServerConfiguration.BaseAddresses.FirstOrDefault();

            _engine = new SimulationEngine(Coordinator, profile.UpdateIntervalMs);
            _engine.Start();

            SetStatus(ServerStatus.Running, $"Listening on {EndpointUrl}");
            OnLog($"Server started. Endpoint: {EndpointUrl}");
            OnLog($"Loaded {profile.Tags.Count} tag(s) and {profile.Commands.Count} command(s).");
        }
        catch (Exception ex)
        {
            SetStatus(ServerStatus.Faulted, ex.Message);
            OnLog($"Failed to start server: {ex.Message}", isError: true);
            await StopAsync().ConfigureAwait(false);
            throw;
        }
    }

    public async Task StopAsync()
    {
        try
        {
            _engine?.Stop();
            _engine?.Dispose();
            _engine = null;

            if (_server is not null)
            {
                OnLog("Stopping server...");
                await _server.StopAsync().ConfigureAwait(false);
                _server.Dispose();
                _server = null;
            }

            _application = null;
            EndpointUrl = null;

            if (Status != ServerStatus.Faulted)
            {
                SetStatus(ServerStatus.Stopped);
            }

            OnLog("Server stopped.");
        }
        catch (Exception ex)
        {
            OnLog($"Error while stopping server: {ex.Message}", isError: true);
        }
    }

    private void OnCertificateValidation(CertificateValidator sender, CertificateValidationEventArgs e)
    {
        if (e.Error.StatusCode != StatusCodes.BadCertificateUntrusted)
        {
            return;
        }

        if (AutoAcceptUntrustedCertificates)
        {
            e.Accept = true;
            OnLog($"Auto-accepted untrusted certificate: {e.Certificate.Subject}");
        }
        else
        {
            OnLog($"Rejected untrusted certificate: {e.Certificate.Subject}", isError: true);
        }
    }

    private void SetStatus(ServerStatus status, string? message = null)
    {
        Status = status;
        StatusChanged?.Invoke(this, new ServerStatusEventArgs(status, message));
    }

    private void OnLog(string message, bool isError = false) =>
        Log?.Invoke(this, new LogEventArgs(message, isError));

    public async ValueTask DisposeAsync() => await StopAsync().ConfigureAwait(false);
}
