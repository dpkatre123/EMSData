using Opc.Ua;
using Opc.Ua.Server;
using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.Core.Server;

/// <summary>
/// The simulator's OPC UA server. Hosts a single <see cref="SimulationNodeManager"/>
/// built from the supplied profile.
/// </summary>
public sealed class SimulationServer(SimProfile profile, WriteCoordinator coordinator) : StandardServer
{
    private readonly SimProfile _profile = profile;
    private readonly WriteCoordinator _coordinator = coordinator;

    public SimulationNodeManager? NodeManager { get; private set; }

    protected override MasterNodeManager CreateMasterNodeManager(
        IServerInternal server,
        ApplicationConfiguration configuration)
    {
        NodeManager = new SimulationNodeManager(server, configuration, _profile, _coordinator);
        return new MasterNodeManager(server, configuration, dynamicNamespaceUri: null, NodeManager);
    }

    protected override ServerProperties LoadServerProperties() => new()
    {
        ManufacturerName = "GES",
        ProductName = "OPC UA Simulator",
        ProductUri = "urn:ges.com:OpcUaSimulator",
        SoftwareVersion = Utils.GetAssemblySoftwareVersion(),
        BuildNumber = Utils.GetAssemblyBuildNumber(),
        BuildDate = Utils.GetAssemblyTimestamp()
    };
}
