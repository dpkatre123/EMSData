using System.Reflection;
using Opc.Ua;
using Opc.Ua.Server;
using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Simulation;

namespace OpcUaSimulator.Core.Server;

/// <summary>
/// Builds and maintains the simulator's custom address space.
///
/// Folder/variable nodes are generated from the loaded <see cref="SimProfile"/>. All value
/// mutations are routed through <see cref="WriteCoordinator"/> so client writes and the
/// simulation timer cannot race each other.
/// </summary>
public sealed class SimulationNodeManager : CustomNodeManager2
{
    private readonly SimProfile _profile;
    private readonly WriteCoordinator _coordinator;
    private readonly Dictionary<string, BaseDataVariableState> _variables = new(StringComparer.Ordinal);
    private readonly Dictionary<NodeId, string> _methodNodeIds = [];
    private readonly SimulationCommandHandlers _commandHandlers;
    private FolderState? _rootFolder;

    public SimulationNodeManager(
        IServerInternal server,
        ApplicationConfiguration configuration,
        SimProfile profile,
        WriteCoordinator coordinator)
        : base(server, configuration, profile.NamespaceUri)
    {
        _profile = profile;
        _coordinator = coordinator;
        _commandHandlers = new SimulationCommandHandlers(coordinator);

        SystemContext.NodeIdFactory = this;

        _coordinator.ValueChanged += OnCoordinatorValueChanged;
    }

    /// <summary>Namespace index assigned to this manager's custom nodes.</summary>
    public ushort SimNamespaceIndex => NamespaceIndexes[0];

    public override NodeId New(ISystemContext context, NodeState node) => node.NodeId;

    public override void CreateAddressSpace(IDictionary<NodeId, IList<IReference>> externalReferences)
    {
        lock (Lock)
        {
            if (!externalReferences.TryGetValue(ObjectIds.ObjectsFolder, out var references))
            {
                externalReferences[ObjectIds.ObjectsFolder] = references = [];
            }

            _rootFolder = CreateFolder(null, "Simulator", "Simulator");
            _rootFolder.AddReference(ReferenceTypeIds.Organizes, isInverse: true, ObjectIds.ObjectsFolder);
            references.Add(new NodeStateReference(ReferenceTypeIds.Organizes, isInverse: false, _rootFolder.NodeId));
            _rootFolder.EventNotifier = EventNotifiers.SubscribeToEvents;

            AddRootNotifier(_rootFolder);

            CreateTagNodes(_rootFolder);
            CreateCommandNodes(_rootFolder);

            AddPredefinedNode(SystemContext, _rootFolder);
        }
    }

    private void CreateTagNodes(FolderState root)
    {
        // Folders are created on demand so profile authors can use arbitrary paths.
        var folderCache = new Dictionary<string, FolderState>(StringComparer.OrdinalIgnoreCase);

        foreach (var tag in _profile.Tags)
        {
            var parent = ResolveFolder(root, tag.FolderPath, folderCache);
            var variable = CreateVariable(parent, tag);
            _variables[tag.NodeId] = variable;
        }
    }

    private FolderState ResolveFolder(FolderState root, string? folderPath, Dictionary<string, FolderState> cache)
    {
        if (string.IsNullOrWhiteSpace(folderPath))
        {
            return root;
        }

        var current = root;
        var accumulated = string.Empty;

        foreach (var segment in folderPath.Split('/', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            accumulated = string.IsNullOrEmpty(accumulated) ? segment : $"{accumulated}/{segment}";

            if (!cache.TryGetValue(accumulated, out var folder))
            {
                folder = CreateFolder(current, accumulated, segment);
                cache[accumulated] = folder;
            }

            current = folder;
        }

        return current;
    }

    private FolderState CreateFolder(NodeState? parent, string path, string name)
    {
        var folder = new FolderState(parent)
        {
            SymbolicName = name,
            ReferenceTypeId = ReferenceTypes.Organizes,
            TypeDefinitionId = ObjectTypeIds.FolderType,
            NodeId = new NodeId(path, SimNamespaceIndex),
            BrowseName = new QualifiedName(name, SimNamespaceIndex),
            DisplayName = new LocalizedText(name),
            WriteMask = AttributeWriteMask.None,
            UserWriteMask = AttributeWriteMask.None,
            EventNotifier = EventNotifiers.None
        };

        parent?.AddChild(folder);
        return folder;
    }

    private BaseDataVariableState CreateVariable(NodeState parent, SimTag tag)
    {
        var variable = new BaseDataVariableState(parent)
        {
            SymbolicName = tag.BrowseName,
            ReferenceTypeId = ReferenceTypes.Organizes,
            TypeDefinitionId = VariableTypeIds.BaseDataVariableType,
            NodeId = new NodeId(tag.NodeId, SimNamespaceIndex),
            BrowseName = new QualifiedName(tag.BrowseName, SimNamespaceIndex),
            DisplayName = new LocalizedText(tag.BrowseName),
            Description = tag.Unit is null ? null : new LocalizedText($"Unit: {tag.Unit}"),
            DataType = MapDataType(tag.DataType),
            ValueRank = ValueRanks.Scalar,
            Value = ValueCoercion.FromDouble(tag.InitialValue, tag.DataType),
            StatusCode = StatusCodes.Good,
            Timestamp = DateTime.UtcNow,
            WriteMask = AttributeWriteMask.None,
            UserWriteMask = AttributeWriteMask.None,
            Historizing = false
        };

        // AccessLevel is the contract clients inspect before attempting a write.
        var accessLevel = tag.IsWritable
            ? (byte)(AccessLevels.CurrentRead | AccessLevels.CurrentWrite)
            : AccessLevels.CurrentRead;

        variable.AccessLevel = accessLevel;
        variable.UserAccessLevel = accessLevel;

        if (tag.IsWritable)
        {
            variable.OnSimpleWriteValue = OnSimpleWriteValue;
        }

        // Expose engineering range so clients can render gauges correctly.
        if (tag.DataType is SimDataType.Double or SimDataType.Float or SimDataType.Int32 or SimDataType.Int64)
        {
            var range = new PropertyState<Opc.Ua.Range>(variable)
            {
                NodeId = new NodeId($"{tag.NodeId}.EURange", SimNamespaceIndex),
                BrowseName = BrowseNames.EURange,
                DisplayName = new LocalizedText(BrowseNames.EURange),
                TypeDefinitionId = VariableTypeIds.PropertyType,
                ReferenceTypeId = ReferenceTypeIds.HasProperty,
                DataType = DataTypeIds.Range,
                ValueRank = ValueRanks.Scalar,
                Value = new Opc.Ua.Range(tag.Max, tag.Min),
                AccessLevel = AccessLevels.CurrentRead,
                UserAccessLevel = AccessLevels.CurrentRead
            };

            variable.AddChild(range);
        }

        parent.AddChild(variable);
        return variable;
    }

    private void CreateCommandNodes(FolderState root)
    {
        if (_profile.Commands.Count == 0)
        {
            return;
        }

        var commandsFolder = CreateFolder(root, "Commands", "Commands");

        foreach (var command in _profile.Commands)
        {
            var method = new MethodState(commandsFolder)
            {
                SymbolicName = command.Name,
                ReferenceTypeId = ReferenceTypeIds.HasComponent,
                NodeId = new NodeId(command.NodeId, SimNamespaceIndex),
                BrowseName = new QualifiedName(command.Name, SimNamespaceIndex),
                DisplayName = new LocalizedText(command.Name),
                Description = command.Description is null ? null : new LocalizedText(command.Description),
                Executable = true,
                UserExecutable = true
            };

            if (command.InputArguments.Count > 0)
            {
                method.InputArguments = CreateArgumentProperty(
                    method, command.NodeId, BrowseNames.InputArguments, command.InputArguments);
            }

            if (command.OutputArguments.Count > 0)
            {
                method.OutputArguments = CreateArgumentProperty(
                    method, command.NodeId, BrowseNames.OutputArguments, command.OutputArguments);
            }

            method.OnCallMethod = OnCallMethod;
            _methodNodeIds[method.NodeId] = command.HandlerKey;

            commandsFolder.AddChild(method);
        }
    }

    private PropertyState<Argument[]> CreateArgumentProperty(
        MethodState parent,
        string commandNodeId,
        string browseName,
        List<SimArgument> arguments)
    {
        return new PropertyState<Argument[]>(parent)
        {
            NodeId = new NodeId($"{commandNodeId}.{browseName}", SimNamespaceIndex),
            BrowseName = new QualifiedName(browseName, (ushort)0),
            DisplayName = new LocalizedText(browseName),
            TypeDefinitionId = VariableTypeIds.PropertyType,
            ReferenceTypeId = ReferenceTypeIds.HasProperty,
            DataType = DataTypeIds.Argument,
            ValueRank = ValueRanks.OneDimension,
            AccessLevel = AccessLevels.CurrentRead,
            UserAccessLevel = AccessLevels.CurrentRead,
            Value = [.. arguments.Select(a => new Argument
            {
                Name = a.Name,
                Description = a.Description is null ? null : new LocalizedText(a.Description),
                DataType = MapDataType(a.DataType),
                ValueRank = ValueRanks.Scalar
            })]
        };
    }

    /// <summary>
    /// Intercepts a client write. Returns the coordinator's status code verbatim so the
    /// client sees the true reason for a rejection.
    /// </summary>
    private ServiceResult OnSimpleWriteValue(ISystemContext context, NodeState node, ref object value)
    {
        var tagId = GetIdentifier(node.NodeId);
        if (tagId is null)
        {
            return StatusCodes.BadNodeIdUnknown;
        }

        var identity = ResolveIdentity(context);
        var hasWriteRole = HasWriteRole(context);

        var outcome = _coordinator.ApplyClientWrite(tagId, value, identity, hasWriteRole);

        if (!outcome.Accepted)
        {
            return new ServiceResult(outcome.StatusCode, outcome.Message ?? string.Empty);
        }

        // Hand the coerced value back so the node stores the canonical type.
        if (_coordinator.TryGetRuntime(tagId, out var runtime) && runtime is not null)
        {
            value = runtime.Value!;
        }

        return ServiceResult.Good;
    }

    private ServiceResult OnCallMethod(
        ISystemContext context,
        MethodState method,
        IList<object> inputArguments,
        IList<object> outputArguments)
    {
        if (!_methodNodeIds.TryGetValue(method.NodeId, out var handlerKey))
        {
            return StatusCodes.BadNodeIdUnknown;
        }

        var identity = ResolveIdentity(context);
        var hasWriteRole = HasWriteRole(context);

        return _commandHandlers.Invoke(handlerKey, identity, hasWriteRole, inputArguments, outputArguments);
    }

    /// <summary>
    /// Pushes a committed value change into the address space and notifies subscribers.
    /// </summary>
    private void OnCoordinatorValueChanged(object? sender, TagValueChangedEventArgs e)
    {
        BaseDataVariableState? variable;

        lock (Lock)
        {
            if (!_variables.TryGetValue(e.NodeId, out variable))
            {
                return;
            }

            variable.Value = e.Value;
            variable.StatusCode = e.StatusCode;
            variable.Timestamp = e.SourceTimestampUtc;

            // Required for subscribed clients to receive the data change notification.
            variable.ClearChangeMasks(SystemContext, includeChildren: false);
        }
    }

    private string? GetIdentifier(NodeId nodeId) => nodeId?.Identifier as string;

    private static string ResolveIdentity(ISystemContext context)
    {
        var identity = GetUserIdentity(context);
        if (identity is null)
        {
            return "anonymous";
        }

        return string.IsNullOrWhiteSpace(identity.DisplayName) ? "anonymous" : identity.DisplayName;
    }

    /// <summary>
    /// Anonymous sessions are read-only; any authenticated (username) session gets the write role.
    /// </summary>
    private static bool HasWriteRole(ISystemContext context)
    {
        var identity = GetUserIdentity(context);
        return identity is not null && identity.TokenType != UserTokenType.Anonymous;
    }

    /// <summary>
    /// The user identity lives on <see cref="ServerSystemContext"/>, not on the
    /// <see cref="ISystemContext"/> base interface, so it must be resolved by cast.
    /// </summary>
    private static IUserIdentity? GetUserIdentity(ISystemContext context) =>
        (context as ServerSystemContext)?.UserIdentity;

    private static NodeId MapDataType(SimDataType dataType) => dataType switch
    {
        SimDataType.Double => DataTypeIds.Double,
        SimDataType.Float => DataTypeIds.Float,
        SimDataType.Int32 => DataTypeIds.Int32,
        SimDataType.Int64 => DataTypeIds.Int64,
        SimDataType.Boolean => DataTypeIds.Boolean,
        SimDataType.String => DataTypeIds.String,
        _ => DataTypeIds.BaseDataType
    };

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _coordinator.ValueChanged -= OnCoordinatorValueChanged;
        }

        base.Dispose(disposing);
    }
}
