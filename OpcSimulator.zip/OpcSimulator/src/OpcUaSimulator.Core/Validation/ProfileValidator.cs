using OpcUaSimulator.Core.Model;

namespace OpcUaSimulator.Core.Validation;

/// <summary>
/// Result of validating a <see cref="SimProfile"/>.
/// </summary>
public sealed class ValidationResult
{
    public List<string> Errors { get; } = [];

    public bool IsValid => Errors.Count == 0;

    public void ThrowIfInvalid()
    {
        if (!IsValid)
        {
            throw new InvalidOperationException(
                "Profile validation failed:" + Environment.NewLine + string.Join(Environment.NewLine, Errors));
        }
    }
}

/// <summary>
/// Validates profile structure before it is turned into an OPC UA address space.
/// Catching these here avoids obscure failures deep inside the node manager.
/// </summary>
public static class ProfileValidator
{
    private static readonly char[] InvalidNodeIdChars = [' ', '\t', '\r', '\n'];

    public static ValidationResult Validate(SimProfile profile)
    {
        ArgumentNullException.ThrowIfNull(profile);

        var result = new ValidationResult();

        if (string.IsNullOrWhiteSpace(profile.NamespaceUri))
        {
            result.Errors.Add("Profile NamespaceUri must not be empty.");
        }

        if (profile.UpdateIntervalMs < 50)
        {
            result.Errors.Add($"Profile UpdateIntervalMs must be at least 50 ms (was {profile.UpdateIntervalMs}).");
        }

        // NodeIds must be unique across BOTH tags and commands: they share one address space.
        var seenNodeIds = new HashSet<string>(StringComparer.Ordinal);

        foreach (var tag in profile.Tags)
        {
            ValidateNodeId(tag.NodeId, "Tag", result, seenNodeIds);

            if (string.IsNullOrWhiteSpace(tag.BrowseName))
            {
                result.Errors.Add($"Tag '{tag.NodeId}' has an empty BrowseName.");
            }

            if (tag.Max < tag.Min)
            {
                result.Errors.Add($"Tag '{tag.NodeId}' has Max ({tag.Max}) less than Min ({tag.Min}).");
            }

            if (tag.PeriodMs <= 0 && RequiresPeriod(tag.SignalType))
            {
                result.Errors.Add($"Tag '{tag.NodeId}' uses {tag.SignalType} but PeriodMs is {tag.PeriodMs}; must be greater than zero.");
            }

            if (tag.NoisePercent is < 0 or > 100)
            {
                result.Errors.Add($"Tag '{tag.NodeId}' has NoisePercent {tag.NoisePercent}; must be between 0 and 100.");
            }

            if (tag.ControlMode == ControlMode.Hybrid && tag.HoldSeconds <= 0)
            {
                result.Errors.Add($"Tag '{tag.NodeId}' is Hybrid but HoldSeconds is {tag.HoldSeconds}; must be greater than zero.");
            }
        }

        foreach (var command in profile.Commands)
        {
            ValidateNodeId(command.NodeId, "Command", result, seenNodeIds);

            if (string.IsNullOrWhiteSpace(command.Name))
            {
                result.Errors.Add($"Command '{command.NodeId}' has an empty Name.");
            }

            if (string.IsNullOrWhiteSpace(command.HandlerKey))
            {
                result.Errors.Add($"Command '{command.NodeId}' has an empty HandlerKey.");
            }

            var argNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var arg in command.InputArguments)
            {
                if (!argNames.Add(arg.Name))
                {
                    result.Errors.Add($"Command '{command.NodeId}' has duplicate input argument '{arg.Name}'.");
                }
            }
        }

        return result;
    }

    private static bool RequiresPeriod(SignalType signalType) => signalType is
        SignalType.Ramp or SignalType.Sine or SignalType.Square or SignalType.BooleanToggle;

    private static void ValidateNodeId(string nodeId, string kind, ValidationResult result, HashSet<string> seen)
    {
        if (string.IsNullOrWhiteSpace(nodeId))
        {
            result.Errors.Add($"{kind} has an empty NodeId.");
            return;
        }

        if (nodeId.IndexOfAny(InvalidNodeIdChars) >= 0)
        {
            result.Errors.Add($"{kind} NodeId '{nodeId}' contains whitespace, which is not allowed.");
        }

        if (!seen.Add(nodeId))
        {
            result.Errors.Add($"Duplicate NodeId '{nodeId}' found; NodeIds must be unique across tags and commands.");
        }
    }
}
