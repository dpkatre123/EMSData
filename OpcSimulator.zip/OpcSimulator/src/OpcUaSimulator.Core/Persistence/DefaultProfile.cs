using OpcUaSimulator.Core.Model;

namespace OpcUaSimulator.Core.Persistence;

/// <summary>
/// The built-in energy/industrial profile. Used when no profile file is present so the
/// simulator is always immediately runnable.
/// </summary>
public static class DefaultProfile
{
    public static SimProfile CreateEmsProfile()
    {
        var profile = new SimProfile
        {
            Name = "Default EMS",
            Description = "Energy management demo: meters, breakers and inverters.",
            NamespaceUri = "http://ges.com/OpcUaSimulator",
            UpdateIntervalMs = 1000
        };

        AddMeter(profile, "Meter01", basePower: 750d);
        AddMeter(profile, "Meter02", basePower: 420d);
        AddBreaker(profile, "Breaker01");
        AddBreaker(profile, "Breaker02");
        AddInverter(profile, "Inverter01");

        AddCommands(profile);

        return profile;
    }

    private static void AddMeter(SimProfile profile, string name, double basePower)
    {
        var folder = $"Plant/{name}";

        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.ActivePower",
            BrowseName = "ActivePower",
            FolderPath = folder,
            DataType = SimDataType.Double,
            SignalType = SignalType.Sine,
            ControlMode = ControlMode.Simulated,
            Min = 0,
            Max = basePower * 2,
            InitialValue = basePower,
            PeriodMs = 30_000,
            NoisePercent = 2,
            Unit = "kW"
        });

        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.Voltage",
            BrowseName = "Voltage",
            FolderPath = folder,
            DataType = SimDataType.Double,
            SignalType = SignalType.RandomWalk,
            ControlMode = ControlMode.Simulated,
            Min = 220,
            Max = 245,
            InitialValue = 233,
            PeriodMs = 5_000,
            NoisePercent = 1,
            Unit = "V"
        });

        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.Current",
            BrowseName = "Current",
            FolderPath = folder,
            DataType = SimDataType.Double,
            SignalType = SignalType.Sine,
            ControlMode = ControlMode.Simulated,
            Min = 0,
            Max = 200,
            InitialValue = 90,
            PeriodMs = 20_000,
            NoisePercent = 3,
            Unit = "A"
        });

        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.EnergyTotal",
            BrowseName = "EnergyTotal",
            FolderPath = folder,
            DataType = SimDataType.Double,
            SignalType = SignalType.Counter,
            ControlMode = ControlMode.Simulated,
            Min = 0,
            Max = 1_000_000,
            InitialValue = 0,
            PeriodMs = 600_000,
            Unit = "kWh"
        });
    }

    private static void AddBreaker(SimProfile profile, string name)
    {
        var folder = $"Plant/{name}";

        // Writable: clients open/close it directly or via the OpenBreaker/CloseBreaker methods.
        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.Open",
            BrowseName = "Open",
            FolderPath = folder,
            DataType = SimDataType.Boolean,
            SignalType = SignalType.Constant,
            ControlMode = ControlMode.Setpoint,
            Min = 0,
            Max = 1,
            InitialValue = 0
        });

        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.TripCount",
            BrowseName = "TripCount",
            FolderPath = folder,
            DataType = SimDataType.Int32,
            SignalType = SignalType.Constant,
            ControlMode = ControlMode.Simulated,
            Min = 0,
            Max = 1000,
            InitialValue = 0
        });
    }

    private static void AddInverter(SimProfile profile, string name)
    {
        var folder = $"Plant/{name}";

        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.DcPower",
            BrowseName = "DcPower",
            FolderPath = folder,
            DataType = SimDataType.Double,
            SignalType = SignalType.Sine,
            ControlMode = ControlMode.Simulated,
            Min = 0,
            Max = 500,
            InitialValue = 250,
            PeriodMs = 60_000,
            NoisePercent = 4,
            Unit = "kW"
        });

        // Hybrid: a client write wins for 60s, then the simulation takes over again.
        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.ActivePowerLimit",
            BrowseName = "ActivePowerLimit",
            FolderPath = folder,
            DataType = SimDataType.Double,
            SignalType = SignalType.Constant,
            ControlMode = ControlMode.Hybrid,
            Min = 0,
            Max = 500,
            InitialValue = 500,
            HoldSeconds = 60,
            Unit = "kW"
        });

        profile.Tags.Add(new SimTag
        {
            NodeId = $"{name}.Mode",
            BrowseName = "Mode",
            FolderPath = folder,
            DataType = SimDataType.String,
            SignalType = SignalType.Constant,
            ControlMode = ControlMode.Setpoint,
            InitialValue = 0
        });
    }

    private static void AddCommands(SimProfile profile)
    {
        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd.OpenBreaker",
            Name = "OpenBreaker",
            HandlerKey = "OpenBreaker",
            Description = "Opens a breaker by writing true to its Open tag.",
            InputArguments = [new SimArgument { Name = "breakerNodeId", DataType = SimDataType.String, Description = "e.g. Breaker01.Open" }],
            OutputArguments = [
                new SimArgument { Name = "success", DataType = SimDataType.Boolean },
                new SimArgument { Name = "message", DataType = SimDataType.String }]
        });

        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd.CloseBreaker",
            Name = "CloseBreaker",
            HandlerKey = "CloseBreaker",
            Description = "Closes a breaker by writing false to its Open tag.",
            InputArguments = [new SimArgument { Name = "breakerNodeId", DataType = SimDataType.String, Description = "e.g. Breaker01.Open" }],
            OutputArguments = [
                new SimArgument { Name = "success", DataType = SimDataType.Boolean },
                new SimArgument { Name = "message", DataType = SimDataType.String }]
        });

        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd.SetActivePowerLimit",
            Name = "SetActivePowerLimit",
            HandlerKey = "SetActivePowerLimit",
            Description = "Sets an inverter active power limit in kW.",
            InputArguments = [
                new SimArgument { Name = "limitNodeId", DataType = SimDataType.String, Description = "e.g. Inverter01.ActivePowerLimit" },
                new SimArgument { Name = "limitKw", DataType = SimDataType.Double }],
            OutputArguments = [
                new SimArgument { Name = "success", DataType = SimDataType.Boolean },
                new SimArgument { Name = "message", DataType = SimDataType.String }]
        });

        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd.ResetEnergyCounter",
            Name = "ResetEnergyCounter",
            HandlerKey = "ResetEnergyCounter",
            Description = "Resets an energy counter tag back to its minimum.",
            InputArguments = [new SimArgument { Name = "counterNodeId", DataType = SimDataType.String, Description = "e.g. Meter01.EnergyTotal" }],
            OutputArguments = [
                new SimArgument { Name = "success", DataType = SimDataType.Boolean },
                new SimArgument { Name = "message", DataType = SimDataType.String }]
        });

        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd.StartSimulation",
            Name = "StartSimulation",
            HandlerKey = "StartSimulation",
            Description = "Starts the simulation engine.",
            OutputArguments = [
                new SimArgument { Name = "success", DataType = SimDataType.Boolean },
                new SimArgument { Name = "message", DataType = SimDataType.String }]
        });

        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd.StopSimulation",
            Name = "StopSimulation",
            HandlerKey = "StopSimulation",
            Description = "Stops the simulation engine.",
            OutputArguments = [
                new SimArgument { Name = "success", DataType = SimDataType.Boolean },
                new SimArgument { Name = "message", DataType = SimDataType.String }]
        });

        profile.Commands.Add(new SimCommand
        {
            NodeId = "Cmd.InjectFault",
            Name = "InjectFault",
            HandlerKey = "InjectFault",
            Description = "Applies a fault to a tag: bad, uncertain, good, freeze or spike.",
            InputArguments = [
                new SimArgument { Name = "tagNodeId", DataType = SimDataType.String },
                new SimArgument { Name = "faultType", DataType = SimDataType.String, Description = "bad | uncertain | good | freeze | spike" }],
            OutputArguments = [
                new SimArgument { Name = "success", DataType = SimDataType.Boolean },
                new SimArgument { Name = "message", DataType = SimDataType.String }]
        });
    }
}
