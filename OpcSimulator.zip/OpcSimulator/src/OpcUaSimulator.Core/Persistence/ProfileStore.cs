using System.Text.Json;
using System.Text.Json.Serialization;
using OpcUaSimulator.Core.Model;
using OpcUaSimulator.Core.Validation;

namespace OpcUaSimulator.Core.Persistence;

/// <summary>
/// Source-generated JSON context. Avoids reflection-based serialization so the
/// library stays trim/AOT friendly if that is ever enabled.
/// </summary>
[JsonSourceGenerationOptions(
    WriteIndented = true,
    PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase,
    UseStringEnumConverter = true)]
[JsonSerializable(typeof(SimProfile))]
public partial class SimProfileJsonContext : JsonSerializerContext
{
}

/// <summary>
/// Loads and saves simulation profiles as JSON.
/// </summary>
public static class ProfileStore
{
    public static string Serialize(SimProfile profile)
    {
        ArgumentNullException.ThrowIfNull(profile);
        return JsonSerializer.Serialize(profile, SimProfileJsonContext.Default.SimProfile);
    }

    public static SimProfile Deserialize(string json)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(json);

        var profile = JsonSerializer.Deserialize(json, SimProfileJsonContext.Default.SimProfile)
            ?? throw new InvalidOperationException("Profile JSON deserialized to null.");

        return profile;
    }

    public static async Task SaveAsync(SimProfile profile, string path, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(profile);
        ArgumentException.ThrowIfNullOrWhiteSpace(path);

        var directory = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        await File.WriteAllTextAsync(path, Serialize(profile), cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Loads a profile and validates it. Throws if the profile is structurally invalid.
    /// </summary>
    public static async Task<SimProfile> LoadAsync(string path, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);

        if (!File.Exists(path))
        {
            throw new FileNotFoundException($"Profile file not found: {path}", path);
        }

        var json = await File.ReadAllTextAsync(path, cancellationToken).ConfigureAwait(false);
        var profile = Deserialize(json);

        ProfileValidator.Validate(profile).ThrowIfInvalid();

        return profile;
    }
}
