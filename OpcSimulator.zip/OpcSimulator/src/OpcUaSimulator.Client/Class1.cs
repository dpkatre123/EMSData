﻿namespace OpcUaSimulator.Client;

public class Class1
{

}
